# RPG Image Restorer (Android)

Offline Android app that restores RPG Maker MV/MZ encrypted images (`.png_`, `.rpgmvp`) into normal PNGs.
No network permission, no analytics, no accounts. Files are accessed through the Storage Access Framework.

## Build (debug APK)

Requirements: Android Studio (Koala or newer) with JDK 17 and Android SDK 35.

1. Android Studio -> **Open** -> select this folder. Accept the Gradle sync (it downloads Gradle 8.9 / AGP 8.6.1).
   If Studio proposes an AGP/Gradle upgrade, accepting it is fine.
2. **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**, or from a terminal:
   `gradle wrapper --gradle-version 8.9` (once, if there is no `gradlew`) then `./gradlew assembleDebug`
3. APK: `app/build/outputs/apk/debug/app-debug.apk`  (enable "Install unknown apps" and install on your phone,
   or `adb install app-debug.apk`).

## Unit tests
`./gradlew testDebugUnitTest`  (engine, streaming, file-name and formatter tests; no device needed)

## How restoration works
`file = 16-byte fake RPGMV header + 16 encrypted bytes + rest of PNG`. The first 16 bytes of every PNG are constant,
so the encrypted block is replaced with them (no key needed). Output is checked for the PNG signature, the IEND
trailer, and a real decode with `BitmapFactory`. Anything that fails is discarded and reported, never saved.

## Layout
- `converter/` restoration engine (pure Kotlin, no Android classes)
- `data/` SAF scanning, output targets, batch processor, ZIP, share, settings
- `models/` state and result types  - `utils/` names, validation, formatting
- `ui/` Compose theme, components, screens, ViewModel

## Attribution
The key-free restoration technique is the one documented by Petschko's RPG-Maker MV & MZ Decrypter
(https://petschko.org/tools/mv_decrypter). This code is an independent implementation; no source was copied.
Check that project's repository license before redistributing anything derived from it.
