package com.example.rpgrestorer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun AppLogo(modifier: Modifier = Modifier, logoSize: Dp = 44.dp) {
    val primary = MaterialTheme.colorScheme.primary
    val cutout = MaterialTheme.colorScheme.background
    Canvas(modifier.size(logoSize)) {
        val s = this.size.minDimension
        drawRoundRect(color = primary, cornerRadius = CornerRadius(s * 0.28f), size = this.size)
        val mountains = Path().apply {
            moveTo(s * 0.18f, s * 0.74f)
            lineTo(s * 0.40f, s * 0.46f)
            lineTo(s * 0.55f, s * 0.64f)
            lineTo(s * 0.67f, s * 0.52f)
            lineTo(s * 0.82f, s * 0.74f)
            close()
        }
        drawPath(mountains, cutout)
        drawCircle(cutout, radius = s * 0.08f, center = Offset(s * 0.68f, s * 0.30f))
    }
}
