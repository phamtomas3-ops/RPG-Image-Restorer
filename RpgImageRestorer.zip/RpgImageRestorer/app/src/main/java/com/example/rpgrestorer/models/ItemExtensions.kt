package com.example.rpgrestorer.models

val List<ConversionItem>.doneCount: Int
    get() = count { it.status !is ConversionStatus.Pending && it.status !is ConversionStatus.Running }

val List<ConversionItem>.successCount: Int
    get() = count { it.status is ConversionStatus.Success }

val List<ConversionItem>.failedCount: Int
    get() = count { it.status is ConversionStatus.Failed }

val List<ConversionItem>.skippedCount: Int
    get() = count { it.status is ConversionStatus.Skipped }

val List<ConversionItem>.successful: List<OutputInfo>
    get() = mapNotNull { if (it.status is ConversionStatus.Success) it.output else null }
