package com.example.rpgrestorer.models

/** One file in a batch. [id] equals its index in the batch list. */
data class ConversionItem(
    val id: Int,
    val input: InputFile,
    val status: ConversionStatus = ConversionStatus.Pending,
    val output: OutputInfo? = null
)
