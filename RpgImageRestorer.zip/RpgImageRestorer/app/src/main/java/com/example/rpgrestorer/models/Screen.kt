package com.example.rpgrestorer.models

enum class Screen { HOME, CONVERTING, RESULTS, SETTINGS }
