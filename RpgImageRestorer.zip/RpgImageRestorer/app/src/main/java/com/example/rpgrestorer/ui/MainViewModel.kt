package com.example.rpgrestorer.ui

import android.app.Application
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.rpgrestorer.data.BatchProcessor
import com.example.rpgrestorer.data.FileScanner
import com.example.rpgrestorer.data.LocalDirTarget
import com.example.rpgrestorer.data.OutputTarget
import com.example.rpgrestorer.data.RecentStore
import com.example.rpgrestorer.data.SettingsStore
import com.example.rpgrestorer.data.ShareHelper
import com.example.rpgrestorer.data.TreeTarget
import com.example.rpgrestorer.data.ZipExporter
import com.example.rpgrestorer.models.ConversionItem
import com.example.rpgrestorer.models.ConversionStatus
import com.example.rpgrestorer.models.ExistingFilePolicy
import com.example.rpgrestorer.models.InputFile
import com.example.rpgrestorer.models.OutputInfo
import com.example.rpgrestorer.models.RecentConversion
import com.example.rpgrestorer.models.Screen
import com.example.rpgrestorer.models.ThemeMode
import com.example.rpgrestorer.models.failedCount
import com.example.rpgrestorer.models.skippedCount
import com.example.rpgrestorer.models.successCount
import com.example.rpgrestorer.models.successful
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val context: Context = app.applicationContext
    private val resolver: ContentResolver = app.contentResolver
    private val settings = SettingsStore(context)
    private val recentStore = RecentStore(context)
    private val scanner = FileScanner(resolver)
    private val processor = BatchProcessor(resolver)
    private val restoredRoot = File(context.filesDir, "restored")

    private val _state = MutableStateFlow(
        UiState(
            outputTree = settings.outputTree,
            policy = settings.policy,
            theme = settings.theme,
            recents = recentStore.load()
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events: Flow<UiEvent> = _events.receiveAsFlow()

    private var batchJob: Job? = null

    // ---------- picking & batch conversion ----------

    fun onFilesPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        scanThenStart("Reading selection…") { scanner.describe(uris) }
    }

    fun onFolderPicked(tree: Uri) {
        scanThenStart("Scanning folder…") { scanner.scanTree(tree) }
    }

    private fun scanThenStart(message: String, scan: () -> List<InputFile>) {
        val s = _state.value
        if (s.running || s.busyMessage != null) return
        _state.update { it.copy(busyMessage = message) }
        viewModelScope.launch {
            val files = try {
                withContext(Dispatchers.IO) { scan() }
            } catch (e: Exception) {
                _state.update { it.copy(busyMessage = null) }
                postMessage("Could not read the selection: ${e.message ?: e.javaClass.simpleName}")
                return@launch
            }
            _state.update { it.copy(busyMessage = null) }
            startBatch(files)
        }
    }

    private fun startBatch(files: List<InputFile>) {
        if (files.isEmpty()) {
            postMessage("No .png_ or .rpgmvp files found.")
            return
        }
        val items = files.mapIndexed { index, file -> ConversionItem(id = index, input = file) }
        _state.update { it.copy(items = items, screen = Screen.CONVERTING, running = true) }
        batchJob = viewModelScope.launch { runBatch(items) }
    }

    private suspend fun runBatch(items: List<ConversionItem>) {
        var cancelled = false
        try {
            val target = withContext(Dispatchers.IO) { resolveTarget() }
            processor.run(items, target, _state.value.policy) { updated ->
                _state.update { s ->
                    s.copy(items = s.items.toMutableList().also { list -> list[updated.id] = updated })
                }
            }
        } catch (e: CancellationException) {
            cancelled = true
        } catch (e: Exception) {
            postMessage("Conversion stopped: ${e.message ?: e.javaClass.simpleName}")
        }
        finishBatch(cancelled)
    }

    private fun resolveTarget(): OutputTarget {
        restoredRoot.deleteRecursively() // results of the previous batch are replaced
        val tree = settings.outputTree
        if (tree != null) {
            val writable = resolver.persistedUriPermissions.any { it.uri == tree && it.isWritePermission }
            if (writable) return TreeTarget(resolver, tree)
            settings.outputTree = null
            _state.update { it.copy(outputTree = null) }
            postMessage("The output folder is no longer accessible. Using app storage instead.")
        }
        return LocalDirTarget(File(restoredRoot, "batch_${System.currentTimeMillis()}"))
    }

    private fun finishBatch(cancelled: Boolean) {
        val finalItems = _state.value.items.map {
            if (it.status is ConversionStatus.Pending || it.status is ConversionStatus.Running) {
                it.copy(status = ConversionStatus.Cancelled)
            } else it
        }
        val ok = finalItems.successCount
        val failed = finalItems.failedCount + finalItems.skippedCount
        var recents = _state.value.recents
        if (ok + failed > 0) {
            val first = finalItems.first().input.name
            val label = if (finalItems.size == 1) first else "$first and ${finalItems.size - 1} more"
            recents = recentStore.add(RecentConversion(System.currentTimeMillis(), finalItems.size, ok, failed, label))
        }
        _state.update {
            it.copy(
                items = finalItems,
                running = false,
                recents = recents,
                screen = if (cancelled && ok == 0) Screen.HOME else Screen.RESULTS
            )
        }
        if (cancelled) postMessage("Conversion cancelled. $ok image(s) were already restored.")
    }

    fun cancelBatch() {
        batchJob?.cancel()
    }

    // ---------- navigation ----------

    fun openSettings() = _state.update { it.copy(screen = Screen.SETTINGS) }
    fun openResults() = _state.update { it.copy(screen = Screen.RESULTS) }
    fun goHome() = _state.update { it.copy(screen = Screen.HOME) }

    fun onBack() {
        when (_state.value.screen) {
            Screen.CONVERTING -> cancelBatch()
            Screen.RESULTS, Screen.SETTINGS -> goHome()
            Screen.HOME -> Unit
        }
    }

    // ---------- settings ----------

    fun setTheme(mode: ThemeMode) {
        settings.theme = mode
        _state.update { it.copy(theme = mode) }
    }

    fun setPolicy(policy: ExistingFilePolicy) {
        settings.policy = policy
        _state.update { it.copy(policy = policy) }
    }

    fun onOutputFolderPicked(tree: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try {
            resolver.takePersistableUriPermission(tree, flags)
        } catch (e: SecurityException) {
            postMessage("Could not keep access to that folder. Please pick it again.")
            return
        }
        releaseOutputPermission()
        settings.outputTree = tree
        _state.update { it.copy(outputTree = tree) }
    }

    fun resetOutputFolder() {
        releaseOutputPermission()
        settings.outputTree = null
        _state.update { it.copy(outputTree = null) }
    }

    private fun releaseOutputPermission() {
        val old = settings.outputTree ?: return
        try {
            resolver.releasePersistableUriPermission(
                old, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            // already released
        }
    }

    fun clearRecents() {
        recentStore.clear()
        _state.update { it.copy(recents = emptyList()) }
    }

    fun clearStoredResults() {
        if (_state.value.running) return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { restoredRoot.deleteRecursively() }
            _state.update { s -> s.copy(items = s.items.filter { it.output?.uri?.scheme != "file" }) }
            postMessage("Stored results cleared.")
        }
    }

    // ---------- export & share ----------

    fun shareAll() = share(_state.value.items.successful)

    fun shareOne(image: OutputInfo) = share(listOf(image))

    private fun share(images: List<OutputInfo>) {
        if (images.isEmpty() || _state.value.busyMessage != null) return
        _state.update { it.copy(busyMessage = "Preparing files to share…") }
        viewModelScope.launch {
            try {
                val intent = withContext(Dispatchers.IO) { ShareHelper.buildIntent(context, images) }
                _events.send(UiEvent.Share(intent))
            } catch (e: Exception) {
                postMessage("Could not share: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                _state.update { it.copy(busyMessage = null) }
            }
        }
    }

    fun exportZip(destination: Uri) {
        val images = _state.value.items.successful
        if (images.isEmpty() || _state.value.busyMessage != null) return
        _state.update { it.copy(busyMessage = "Saving ZIP…") }
        viewModelScope.launch {
            try {
                val count = withContext(Dispatchers.IO) {
                    ZipExporter.write(resolver, destination, images) { done, total ->
                        _state.update { it.copy(busyMessage = "Saving ZIP… $done / $total") }
                    }
                }
                postMessage("ZIP saved with $count image(s).")
            } catch (e: Exception) {
                withContext(Dispatchers.IO) {
                    try {
                        DocumentsContract.deleteDocument(resolver, destination)
                    } catch (ignored: Exception) {
                        // best effort cleanup of the partial file
                    }
                }
                postMessage("ZIP export failed: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                _state.update { it.copy(busyMessage = null) }
            }
        }
    }

    fun suggestedZipName(): String = ZipExporter.suggestedName()

    private fun postMessage(text: String) {
        _events.trySend(UiEvent.Message(text))
    }
}
