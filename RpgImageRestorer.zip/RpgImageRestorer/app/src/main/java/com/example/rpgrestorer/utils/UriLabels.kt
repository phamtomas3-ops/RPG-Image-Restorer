package com.example.rpgrestorer.utils

import android.net.Uri

/** Human readable label for a document-tree Uri, e.g. "primary:Download/restored". */
fun folderLabel(uri: Uri): String = Uri.decode(uri.lastPathSegment ?: uri.toString())
