package com.example.rpgrestorer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.example.rpgrestorer.models.ConversionStatus

@Composable
fun StatusIcon(status: ConversionStatus, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    Box(modifier.size(24.dp), contentAlignment = Alignment.Center) {
        when (status) {
            ConversionStatus.Pending ->
                Box(Modifier.size(10.dp).clip(CircleShape).background(colors.outline))
            ConversionStatus.Running ->
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            ConversionStatus.Success ->
                Icon(Icons.Default.CheckCircle, contentDescription = "Restored", tint = colors.primary)
            is ConversionStatus.Failed ->
                Icon(Icons.Default.Warning, contentDescription = "Failed", tint = colors.error)
            is ConversionStatus.Skipped ->
                Icon(Icons.Default.Info, contentDescription = "Skipped", tint = colors.onSurfaceVariant)
            ConversionStatus.Cancelled ->
                Icon(Icons.Default.Close, contentDescription = "Cancelled", tint = colors.onSurfaceVariant)
        }
    }
}
