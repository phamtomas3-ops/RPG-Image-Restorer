package com.example.rpgrestorer.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.rpgrestorer.models.ThemeMode

private val DarkColors = darkColorScheme(
    primary = Green400,
    onPrimary = Color(0xFF00391B),
    primaryContainer = Green900,
    onPrimaryContainer = Green100,
    secondary = Color(0xFF8FB9A0),
    onSecondary = Color(0xFF0A2A18),
    secondaryContainer = Color(0xFF1F3A2B),
    onSecondaryContainer = Color(0xFFCDEBD9),
    background = Night,
    onBackground = NightText,
    surface = Night,
    onSurface = NightText,
    surfaceVariant = NightContainerHigh,
    onSurfaceVariant = NightTextDim,
    surfaceContainer = NightContainer,
    surfaceContainerHigh = NightContainerHigh,
    surfaceContainerHighest = NightContainerHighest,
    outline = NightOutline,
    outlineVariant = NightOutlineVariant,
    error = ErrorSoft,
    errorContainer = ErrorContainerDark,
    onErrorContainer = OnErrorContainerDark
)

private val LightColors = lightColorScheme(
    primary = Green700,
    onPrimary = Color.White,
    primaryContainer = Green100,
    onPrimaryContainer = Color(0xFF00391B),
    background = Color(0xFFF6FAF7),
    surface = Color(0xFFF6FAF7),
    surfaceContainer = Color(0xFFEAF1EC),
    surfaceContainerHigh = Color(0xFFE3ECE6),
    surfaceContainerHighest = Color(0xFFDCE6DF)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun ThemeMode.isDark(): Boolean = when (this) {
    ThemeMode.DARK -> true
    ThemeMode.LIGHT -> false
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
}

@Composable
fun RpgImageRestorerTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
