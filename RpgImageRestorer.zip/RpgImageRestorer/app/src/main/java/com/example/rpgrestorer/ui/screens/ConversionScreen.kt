package com.example.rpgrestorer.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.rpgrestorer.models.ConversionItem
import com.example.rpgrestorer.models.ConversionStatus
import com.example.rpgrestorer.models.doneCount
import com.example.rpgrestorer.models.failedCount
import com.example.rpgrestorer.models.successCount
import com.example.rpgrestorer.ui.components.ItemRow
import com.example.rpgrestorer.ui.components.ScreenHeader
import com.example.rpgrestorer.ui.components.SectionCard
import com.example.rpgrestorer.ui.components.StatChip

@Composable
fun ConversionScreen(
    batch: List<ConversionItem>,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val total = batch.size
    val done = batch.doneCount
    val target = if (total == 0) 0f else done / total.toFloat()
    val progress by animateFloatAsState(target, label = "batchProgress")
    val current = batch.firstOrNull { it.status is ConversionStatus.Running }

    Column(modifier.padding(horizontal = 20.dp)) {
        ScreenHeader("Restoring images")
        SectionCard {
            Text("$done of $total", style = MaterialTheme.typography.headlineMedium)
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 14.dp)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
            )
            Text(
                current?.let { "Current: ${it.input.name}" } ?: "Preparing…",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                Modifier.padding(top = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatChip("Succeeded", batch.successCount, MaterialTheme.colorScheme.primary)
                StatChip("Failed", batch.failedCount, MaterialTheme.colorScheme.error)
            }
        }
        LazyColumn(Modifier.weight(1f).padding(top = 8.dp)) {
            items(batch, key = { it.id }) { ItemRow(it) }
        }
        OutlinedButton(
            onClick = onCancel,
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp).height(52.dp),
            shape = RoundedCornerShape(18.dp)
        ) { Text("Cancel") }
    }
}
