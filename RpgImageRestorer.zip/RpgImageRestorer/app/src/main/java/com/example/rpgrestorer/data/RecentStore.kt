package com.example.rpgrestorer.data

import android.content.Context
import com.example.rpgrestorer.models.RecentConversion
import org.json.JSONArray
import org.json.JSONObject

/** Keeps the last few batch summaries (metadata only, never file contents). */
class RecentStore(context: Context) {
    private val prefs = context.getSharedPreferences("recents", Context.MODE_PRIVATE)

    fun load(): List<RecentConversion> = try {
        val array = JSONArray(prefs.getString(KEY, "[]"))
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            RecentConversion(
                o.getLong("t"), o.getInt("total"), o.getInt("ok"), o.getInt("failed"), o.getString("label")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun add(entry: RecentConversion): List<RecentConversion> {
        val list = (listOf(entry) + load()).take(MAX_ENTRIES)
        save(list)
        return list
    }

    fun clear() = prefs.edit().remove(KEY).apply()

    private fun save(list: List<RecentConversion>) {
        val array = JSONArray()
        list.forEach {
            array.put(
                JSONObject()
                    .put("t", it.timestamp).put("total", it.total).put("ok", it.succeeded)
                    .put("failed", it.failed).put("label", it.label)
            )
        }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    private companion object {
        const val KEY = "list"
        const val MAX_ENTRIES = 10
    }
}
