package com.example.rpgrestorer.data

import android.content.Context
import android.net.Uri
import com.example.rpgrestorer.models.ExistingFilePolicy
import com.example.rpgrestorer.models.ThemeMode

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var policy: ExistingFilePolicy
        get() = ExistingFilePolicy.fromName(prefs.getString("policy", null))
        set(value) = prefs.edit().putString("policy", value.name).apply()

    var theme: ThemeMode
        get() = ThemeMode.fromName(prefs.getString("theme", null))
        set(value) = prefs.edit().putString("theme", value.name).apply()

    var outputTree: Uri?
        get() = prefs.getString("output_tree", null)?.let(Uri::parse)
        set(value) {
            prefs.edit().apply {
                if (value == null) remove("output_tree") else putString("output_tree", value.toString())
            }.apply()
        }
}
