package com.example.rpgrestorer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.rpgrestorer.models.doneCount
import com.example.rpgrestorer.models.failedCount
import com.example.rpgrestorer.models.successCount
import com.example.rpgrestorer.ui.UiState
import com.example.rpgrestorer.ui.components.AppLogo
import com.example.rpgrestorer.ui.components.RecentRow
import com.example.rpgrestorer.ui.components.SectionCard
import com.example.rpgrestorer.utils.folderLabel

@Composable
fun HomeScreen(
    state: UiState,
    onSelectFiles: () -> Unit,
    onSelectFolder: () -> Unit,
    onChangeOutput: () -> Unit,
    onResetOutput: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenResults: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AppLogo()
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("RPG Image Restorer", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Offline · no accounts · no network",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings")
                }
            }
        }
        item {
            SectionCard {
                Text("Restore encrypted images", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Pick .png_ files or a whole game folder. They are converted into normal PNGs on this device.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Button(
                    onClick = onSelectFiles,
                    modifier = Modifier.fillMaxWidth().height(64.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(10.dp))
                    Text("Select files", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(12.dp))
                FilledTonalButton(
                    onClick = onSelectFolder,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.List, contentDescription = null)
                    Spacer(Modifier.width(10.dp))
                    Text("Select folder")
                }
            }
        }
        item {
            SectionCard {
                Text("Save restored images to", style = MaterialTheme.typography.labelLarge)
                Text(
                    state.outputTree?.let { folderLabel(it) }
                        ?: "App storage (use ZIP or Share to keep them)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Row {
                    TextButton(onClick = onChangeOutput) { Text("Choose folder") }
                    if (state.outputTree != null) {
                        TextButton(onClick = onResetOutput) { Text("Use app storage") }
                    }
                }
            }
        }
        if (state.items.isNotEmpty() && !state.running) {
            item {
                val total = state.items.size
                SectionCard {
                    Text("Last batch", style = MaterialTheme.typography.titleMedium)
                    LinearProgressIndicator(
                        progress = { state.items.successCount / total.toFloat() },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp).height(8.dp)
                    )
                    Text(
                        "${state.items.successCount} restored · ${state.items.failedCount} failed · " +
                            "${state.items.doneCount} of $total processed",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = onOpenResults) { Text("View results") }
                }
            }
        }
        item { Text("Recent conversions", style = MaterialTheme.typography.titleMedium) }
        if (state.recents.isEmpty()) {
            item {
                Text(
                    "Nothing yet. Your finished batches will appear here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(state.recents) { RecentRow(it) }
        }
    }
}
