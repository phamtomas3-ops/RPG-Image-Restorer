package com.example.rpgrestorer.models

data class RecentConversion(
    val timestamp: Long,
    val total: Int,
    val succeeded: Int,
    val failed: Int,
    val label: String
)
