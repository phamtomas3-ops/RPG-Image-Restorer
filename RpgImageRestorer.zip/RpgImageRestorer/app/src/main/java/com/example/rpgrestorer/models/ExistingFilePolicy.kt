package com.example.rpgrestorer.models

enum class ExistingFilePolicy(val title: String, val description: String) {
    RENAME("Keep both", "Add a number to the new file name"),
    SKIP("Skip", "Leave the existing file alone and skip this image"),
    OVERWRITE("Replace", "Permanently replace the existing file");

    companion object {
        fun fromName(name: String?): ExistingFilePolicy =
            entries.firstOrNull { it.name == name } ?: RENAME
    }
}
