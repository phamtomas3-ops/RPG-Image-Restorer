package com.example.rpgrestorer.ui

import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rpgrestorer.models.Screen
import com.example.rpgrestorer.ui.components.BusyOverlay
import com.example.rpgrestorer.ui.screens.ConversionScreen
import com.example.rpgrestorer.ui.screens.HomeScreen
import com.example.rpgrestorer.ui.screens.ResultsScreen
import com.example.rpgrestorer.ui.screens.SettingsScreen
import com.example.rpgrestorer.ui.theme.RpgImageRestorerTheme
import com.example.rpgrestorer.ui.theme.isDark
import kotlinx.coroutines.launch

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val activity = context as ComponentActivity
    val dark = state.theme.isDark()
    val snackbar = remember { SnackbarHostState() }

    DisposableEffect(dark) {
        val transparent = android.graphics.Color.TRANSPARENT
        val style = if (dark) SystemBarStyle.dark(transparent) else SystemBarStyle.light(transparent, transparent)
        activity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        onDispose { }
    }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.onFilesPicked(it) }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::onFolderPicked) }
    val pickOutput = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let(vm::onOutputFolderPicked) }
    val createZip = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri -> uri?.let(vm::exportZip) }

    LaunchedEffect(vm) {
        vm.events.collect { event ->
            when (event) {
                is UiEvent.Message -> launch { snackbar.showSnackbar(event.text) }
                is UiEvent.Share -> try {
                    context.startActivity(Intent.createChooser(event.intent, "Share restored images"))
                } catch (e: Exception) {
                    launch { snackbar.showSnackbar("No app available to share with.") }
                }
            }
        }
    }

    BackHandler(enabled = state.screen != Screen.HOME) { vm.onBack() }

    RpgImageRestorerTheme(darkTheme = dark) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snackbar) }
        ) { inner ->
            Box(Modifier.fillMaxSize()) {
                AnimatedContent(
                    targetState = state.screen,
                    transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
                    label = "screen"
                ) { screen ->
                    val padded = Modifier.fillMaxSize().padding(inner)
                    when (screen) {
                        Screen.HOME -> HomeScreen(
                            state = state,
                            onSelectFiles = { pickFiles.launch(arrayOf("*/*")) },
                            onSelectFolder = { pickFolder.launch(null) },
                            onChangeOutput = { pickOutput.launch(null) },
                            onResetOutput = vm::resetOutputFolder,
                            onOpenSettings = vm::openSettings,
                            onOpenResults = vm::openResults,
                            modifier = padded
                        )
                        Screen.CONVERTING -> ConversionScreen(
                            batch = state.items,
                            onCancel = vm::cancelBatch,
                            modifier = padded
                        )
                        Screen.RESULTS -> ResultsScreen(
                            batch = state.items,
                            onBack = vm::goHome,
                            onSaveZip = { createZip.launch(vm.suggestedZipName()) },
                            onShareAll = vm::shareAll,
                            onShareOne = vm::shareOne,
                            modifier = padded
                        )
                        Screen.SETTINGS -> SettingsScreen(
                            state = state,
                            onBack = vm::goHome,
                            onTheme = vm::setTheme,
                            onPolicy = vm::setPolicy,
                            onChooseOutput = { pickOutput.launch(null) },
                            onResetOutput = vm::resetOutputFolder,
                            onClearStorage = vm::clearStoredResults,
                            onClearRecents = vm::clearRecents,
                            modifier = padded
                        )
                    }
                }
                state.busyMessage?.let { BusyOverlay(it) }
            }
        }
    }
}
