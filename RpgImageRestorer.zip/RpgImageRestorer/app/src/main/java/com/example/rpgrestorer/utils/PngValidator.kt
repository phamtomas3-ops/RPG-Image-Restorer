package com.example.rpgrestorer.utils

import android.content.ContentResolver
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.rpgrestorer.models.ImageInfo
import java.io.IOException
import kotlin.math.max

/** Verifies that a restored file really decodes as a PNG, using a down-sampled decode to keep memory low. */
object PngValidator {
    private const val VERIFY_MAX_EDGE = 1024

    fun inspect(resolver: ContentResolver, uri: Uri): Result<ImageInfo> {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            val first = resolver.openInputStream(uri)
                ?: return Result.failure(IOException("Cannot reopen output file"))
            first.use { BitmapFactory.decodeStream(it, null, bounds) }
            val w = bounds.outWidth
            val h = bounds.outHeight
            if (w <= 0 || h <= 0 || bounds.outMimeType != "image/png") {
                return Result.failure(IOException("Restored data is not a decodable PNG"))
            }
            var sample = 1
            while (max(w, h) / sample > VERIFY_MAX_EDGE) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val second = resolver.openInputStream(uri)
                ?: return Result.failure(IOException("Cannot reopen output file"))
            val bitmap = second.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return Result.failure(IOException("PNG data could not be decoded (corrupted?)"))
            bitmap.recycle()
            return Result.success(ImageInfo(w, h))
        } catch (e: OutOfMemoryError) {
            return Result.failure(IOException("Not enough memory to verify this image"))
        } catch (e: Exception) {
            return Result.failure(IOException(e.message ?: "Verification failed"))
        }
    }
}
