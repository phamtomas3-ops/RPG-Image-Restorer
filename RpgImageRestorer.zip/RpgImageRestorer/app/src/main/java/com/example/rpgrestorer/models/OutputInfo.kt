package com.example.rpgrestorer.models

import android.net.Uri

data class OutputInfo(
    val uri: Uri,
    val name: String,
    val width: Int,
    val height: Int,
    val sizeBytes: Long
)
