package com.example.rpgrestorer.data

import android.content.ContentResolver
import android.net.Uri
import com.example.rpgrestorer.models.OutputInfo
import com.example.rpgrestorer.utils.FileNames
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Streams restored images into a ZIP file (constant memory). */
object ZipExporter {

    fun suggestedName(): String =
        "restored_images_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".zip"

    /** Returns the number of images written. */
    fun write(
        resolver: ContentResolver,
        destination: Uri,
        images: List<OutputInfo>,
        onProgress: (done: Int, total: Int) -> Unit
    ): Int {
        val raw = resolver.openOutputStream(destination, "wt")
            ?: throw IOException("Cannot open the ZIP destination")
        val usedNames = HashSet<String>()
        var count = 0
        ZipOutputStream(raw.buffered(64 * 1024)).use { zip ->
            zip.setLevel(Deflater.BEST_SPEED) // PNG data is already compressed
            for (image in images) {
                var entryName = image.name
                var n = 1
                while (!usedNames.add(entryName.lowercase())) {
                    entryName = FileNames.withSuffix(image.name, n++)
                }
                zip.putNextEntry(ZipEntry(entryName))
                val input = resolver.openInputStream(image.uri)
                    ?: throw IOException("Cannot read ${image.name}")
                input.use { it.copyTo(zip, 64 * 1024) }
                zip.closeEntry()
                count++
                onProgress(count, images.size)
            }
        }
        return count
    }
}
