package com.example.rpgrestorer.data

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import com.example.rpgrestorer.models.InputFile
import com.example.rpgrestorer.utils.FileNames

/** Turns picked Uris into [InputFile]s: either individual documents or a whole folder tree. */
class FileScanner(private val resolver: ContentResolver) {

    fun describe(uris: List<Uri>): List<InputFile> = uris.map { uri ->
        var name: String? = null
        var size = -1L
        try {
            resolver.query(
                uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (e: Exception) {
            // fall back to the Uri's last segment
        }
        InputFile(uri, name ?: uri.lastPathSegment ?: "file", size)
    }

    /** Recursively collects every supported file below [tree]. */
    fun scanTree(tree: Uri): List<InputFile> {
        val result = ArrayList<InputFile>()
        val pending = kotlin.collections.ArrayDeque<String>()
        pending.add(DocumentsContract.getTreeDocumentId(tree))
        while (pending.isNotEmpty()) {
            val dirId = pending.removeLast()
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, dirId)
            try {
                resolver.query(
                    childrenUri,
                    arrayOf(
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE,
                        DocumentsContract.Document.COLUMN_SIZE
                    ),
                    null, null, null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0)
                        val name = c.getString(1) ?: ""
                        val mime = c.getString(2)
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            pending.add(id)
                        } else if (FileNames.isSupported(name)) {
                            val size = if (c.isNull(3)) -1L else c.getLong(3)
                            result += InputFile(
                                DocumentsContract.buildDocumentUriUsingTree(tree, id), name, size
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                // unreadable sub-folder: skip it and keep scanning
            }
        }
        return result.sortedBy { it.name.lowercase() }
    }
}
