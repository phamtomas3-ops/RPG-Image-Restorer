package com.example.rpgrestorer.models

sealed interface ConversionStatus {
    data object Pending : ConversionStatus
    data object Running : ConversionStatus
    data object Success : ConversionStatus
    data class Failed(val reason: String) : ConversionStatus
    data class Skipped(val reason: String) : ConversionStatus
    data object Cancelled : ConversionStatus
}
