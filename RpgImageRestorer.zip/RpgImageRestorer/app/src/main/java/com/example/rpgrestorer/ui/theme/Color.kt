package com.example.rpgrestorer.ui.theme

import androidx.compose.ui.graphics.Color

val Green400 = Color(0xFF4ADE80)
val Green900 = Color(0xFF0B5A2E)
val Green100 = Color(0xFFB7F5CD)
val Green700 = Color(0xFF16A34A)

val Night = Color(0xFF0E1311)
val NightContainer = Color(0xFF141B18)
val NightContainerHigh = Color(0xFF1A2420)
val NightContainerHighest = Color(0xFF222D28)
val NightOutline = Color(0xFF3A4A42)
val NightOutlineVariant = Color(0xFF25322B)
val NightText = Color(0xFFE2E8E4)
val NightTextDim = Color(0xFF9BADA3)

val ErrorSoft = Color(0xFFFF6B6B)
val ErrorContainerDark = Color(0xFF4A1A1A)
val OnErrorContainerDark = Color(0xFFFFB4B4)
