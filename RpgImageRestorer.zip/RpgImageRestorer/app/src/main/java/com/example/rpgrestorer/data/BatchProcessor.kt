package com.example.rpgrestorer.data

import android.content.ContentResolver
import com.example.rpgrestorer.converter.RpgPngRestorer
import com.example.rpgrestorer.models.ConversionItem
import com.example.rpgrestorer.models.ConversionStatus
import com.example.rpgrestorer.models.ExistingFilePolicy
import com.example.rpgrestorer.models.OutputInfo
import com.example.rpgrestorer.utils.CountingOutputStream
import com.example.rpgrestorer.utils.FileNames
import com.example.rpgrestorer.utils.PngValidator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * Converts a batch with bounded parallelism. Every file is streamed (constant memory), verified by
 * decoding, and reported through [onUpdate]. A failing file never stops the rest of the batch.
 */
class BatchProcessor(
    private val resolver: ContentResolver,
    private val parallelism: Int = 3
) {
    suspend fun run(
        items: List<ConversionItem>,
        target: OutputTarget,
        policy: ExistingFilePolicy,
        onUpdate: (ConversionItem) -> Unit
    ) = coroutineScope {
        val gate = Semaphore(parallelism)
        for (item in items) {
            launch(Dispatchers.IO) {
                gate.withPermit { process(item, target, policy, onUpdate) }
            }
        }
    }

    private suspend fun process(
        item: ConversionItem,
        target: OutputTarget,
        policy: ExistingFilePolicy,
        onUpdate: (ConversionItem) -> Unit
    ) {
        val name = item.input.name
        if (!FileNames.isSupported(name)) {
            onUpdate(item.copy(status = ConversionStatus.Failed("Unsupported file type (expected .png_ or .rpgmvp)")))
            return
        }
        onUpdate(item.copy(status = ConversionStatus.Running))
        val ctx = currentCoroutineContext()
        var slot: OutputSlot? = null
        try {
            slot = target.create(FileNames.restoredName(name), policy)
            val active: OutputSlot = slot ?: run {
                onUpdate(item.copy(status = ConversionStatus.Skipped("A file with this name already exists")))
                return
            }
            val input = resolver.openInputStream(item.input.uri)
                ?: throw IOException("Could not open the input file")
            val counter = CountingOutputStream(active.stream)
            val error = input.use { i ->
                counter.use { o -> RpgPngRestorer.restoreStream(i, o) { ctx.ensureActive() } }
            }
            if (error != null) {
                target.discard(active)
                onUpdate(item.copy(status = ConversionStatus.Failed(error)))
                return
            }
            val info = PngValidator.inspect(resolver, active.uri).getOrElse { e ->
                target.discard(active)
                onUpdate(item.copy(status = ConversionStatus.Failed(e.message ?: "Verification failed")))
                return
            }
            onUpdate(
                item.copy(
                    status = ConversionStatus.Success,
                    output = OutputInfo(active.uri, active.name, info.width, info.height, counter.count)
                )
            )
        } catch (e: CancellationException) {
            withContext(NonCancellable) {
                slot?.let { target.discard(it) }
                onUpdate(item.copy(status = ConversionStatus.Cancelled))
            }
            throw e
        } catch (e: Exception) {
            slot?.let { target.discard(it) }
            onUpdate(item.copy(status = ConversionStatus.Failed(e.message ?: e.javaClass.simpleName)))
        }
    }
}
