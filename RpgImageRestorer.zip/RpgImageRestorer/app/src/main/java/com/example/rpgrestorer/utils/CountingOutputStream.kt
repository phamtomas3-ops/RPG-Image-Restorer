package com.example.rpgrestorer.utils

import java.io.OutputStream

/** Wraps a stream and counts the bytes written through it. */
class CountingOutputStream(private val out: OutputStream) : OutputStream() {
    var count: Long = 0
        private set

    override fun write(b: Int) {
        out.write(b)
        count++
    }

    override fun write(b: ByteArray, off: Int, len: Int) {
        out.write(b, off, len)
        count += len
    }

    override fun flush() = out.flush()
    override fun close() = out.close()
}
