package com.example.rpgrestorer.data

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.rpgrestorer.models.OutputInfo
import java.io.File
import java.io.IOException

/** Builds an Android share intent. Files are copied to the cache and exposed through FileProvider. */
object ShareHelper {

    fun buildIntent(context: Context, images: List<OutputInfo>): Intent {
        require(images.isNotEmpty()) { "Nothing to share" }
        val dir = File(context.cacheDir, "share")
        dir.deleteRecursively()
        dir.mkdirs()

        val uris = ArrayList<Uri>(images.size)
        for (image in images) {
            val target = File(dir, image.name)
            val input = context.contentResolver.openInputStream(image.uri)
                ?: throw IOException("Cannot read ${image.name}")
            input.use { i -> target.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
            uris += FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", target)
        }

        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        intent.type = "image/png"
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val clip = ClipData.newUri(context.contentResolver, "Restored images", uris[0])
        uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
        intent.clipData = clip
        return intent
    }
}
