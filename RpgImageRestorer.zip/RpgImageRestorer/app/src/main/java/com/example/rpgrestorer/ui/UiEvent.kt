package com.example.rpgrestorer.ui

import android.content.Intent

sealed interface UiEvent {
    data class Message(val text: String) : UiEvent
    data class Share(val intent: Intent) : UiEvent
}
