package com.example.rpgrestorer.ui

import android.net.Uri
import com.example.rpgrestorer.models.ConversionItem
import com.example.rpgrestorer.models.ExistingFilePolicy
import com.example.rpgrestorer.models.RecentConversion
import com.example.rpgrestorer.models.Screen
import com.example.rpgrestorer.models.ThemeMode

data class UiState(
    val screen: Screen = Screen.HOME,
    val items: List<ConversionItem> = emptyList(),
    val running: Boolean = false,
    val outputTree: Uri? = null,
    val policy: ExistingFilePolicy = ExistingFilePolicy.RENAME,
    val theme: ThemeMode = ThemeMode.DARK,
    val recents: List<RecentConversion> = emptyList(),
    /** Non-null while a short blocking task (scan / ZIP / share preparation) is running. */
    val busyMessage: String? = null
)
