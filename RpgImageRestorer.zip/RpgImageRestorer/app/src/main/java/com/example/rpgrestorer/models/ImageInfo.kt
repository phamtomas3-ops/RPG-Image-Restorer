package com.example.rpgrestorer.models

data class ImageInfo(val width: Int, val height: Int)
