package com.example.rpgrestorer.data

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import java.io.IOException

/** Writes into a folder chosen with the Storage Access Framework (ACTION_OPEN_DOCUMENT_TREE). */
class TreeTarget(
    private val resolver: ContentResolver,
    private val tree: Uri
) : BaseOutputTarget() {
    private val parent: Uri = DocumentsContract.buildDocumentUriUsingTree(
        tree, DocumentsContract.getTreeDocumentId(tree)
    )
    private val existingUris = HashMap<String, Uri>()

    override fun listExisting(): List<String> {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(
            tree, DocumentsContract.getTreeDocumentId(tree)
        )
        val names = ArrayList<String>()
        resolver.query(
            children,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(1) ?: continue
                names += name
                existingUris[name] = DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0))
            }
        }
        return names
    }

    override fun createFile(name: String): OutputSlot {
        val uri = DocumentsContract.createDocument(resolver, parent, "image/png", name)
            ?: throw IOException("Could not create \"$name\" in the output folder")
        val stream = resolver.openOutputStream(uri, "wt")
            ?: throw IOException("Could not open \"$name\" for writing")
        return OutputSlot(uri, name, stream.buffered(64 * 1024))
    }

    override fun deleteExisting(actualName: String) {
        existingUris[actualName]?.let { DocumentsContract.deleteDocument(resolver, it) }
    }

    override suspend fun discard(slot: OutputSlot) {
        runCatching { DocumentsContract.deleteDocument(resolver, slot.uri) }
    }
}
