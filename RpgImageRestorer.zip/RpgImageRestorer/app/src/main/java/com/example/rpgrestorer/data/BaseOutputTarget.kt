package com.example.rpgrestorer.data

import com.example.rpgrestorer.models.ExistingFilePolicy
import com.example.rpgrestorer.utils.FileNames
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Handles file-name allocation, which must be serialized when several conversions run in parallel:
 *  - duplicates inside the same batch always get a numeric suffix,
 *  - files that existed before the batch follow the user's [ExistingFilePolicy].
 */
abstract class BaseOutputTarget : OutputTarget {
    private val lock = Mutex()
    private var preexisting: Map<String, String>? = null // lower-case -> actual name
    private val allocated = HashSet<String>()            // lower-case names used by this batch

    /** Names currently in the destination folder. */
    protected abstract fun listExisting(): List<String>
    protected abstract fun createFile(name: String): OutputSlot
    protected abstract fun deleteExisting(actualName: String)

    override suspend fun create(desiredName: String, policy: ExistingFilePolicy): OutputSlot? =
        lock.withLock {
            val existing = preexisting
                ?: listExisting().associateBy { it.lowercase() }.also { preexisting = it }
            var name = desiredName
            val key = name.lowercase()
            if (key in allocated) {
                name = uniqueName(desiredName, existing)
            } else if (key in existing) {
                when (policy) {
                    ExistingFilePolicy.SKIP -> return@withLock null
                    ExistingFilePolicy.RENAME -> name = uniqueName(desiredName, existing)
                    ExistingFilePolicy.OVERWRITE -> deleteExisting(existing.getValue(key))
                }
            }
            allocated += name.lowercase()
            createFile(name)
        }

    private fun uniqueName(base: String, existing: Map<String, String>): String {
        var n = 1
        var candidate = FileNames.withSuffix(base, n)
        while (candidate.lowercase() in allocated || candidate.lowercase() in existing) {
            n++
            candidate = FileNames.withSuffix(base, n)
        }
        return candidate
    }
}
