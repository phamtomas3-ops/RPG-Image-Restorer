package com.example.rpgrestorer.models

import android.net.Uri

data class InputFile(val uri: Uri, val name: String, val size: Long)
