package com.example.rpgrestorer.data

import android.net.Uri
import com.example.rpgrestorer.models.ExistingFilePolicy
import java.io.OutputStream

/** A freshly created output file, ready to be written to. */
class OutputSlot(val uri: Uri, val name: String, val stream: OutputStream)

/** Destination for restored images (a user-chosen folder or app storage). */
interface OutputTarget {
    /**
     * Reserves a unique file for [desiredName]. Returns null when [policy] is SKIP and a file with
     * that name already existed before the batch started.
     */
    suspend fun create(desiredName: String, policy: ExistingFilePolicy): OutputSlot?

    /** Deletes a partially written file after a failure or cancellation. */
    suspend fun discard(slot: OutputSlot)
}
