package com.example.rpgrestorer.converter

import java.io.InputStream
import java.io.OutputStream

/**
 * Restores RPG Maker MV/MZ encrypted PNGs (.png_ / .rpgmvp) without the encryption key.
 *
 * File layout:  [16-byte fake header "RPGMV..."] [16 bytes of the PNG, XOR-encrypted] [rest of the PNG, plain]
 * Every PNG starts with the same 16 bytes (signature + IHDR length + "IHDR"), so the encrypted
 * block can be replaced by that constant: restored = PNG_HEADER + file[32..].
 *
 * Pure Kotlin/JVM: no Android dependencies, fully unit-testable.
 */
object RpgPngRestorer {
    const val FAKE_HEADER_LEN = 16
    const val PNG_HEAD_LEN = 16
    private const val MIN_PNG_SIZE = 45
    private const val TAIL_LEN = 8

    /** 89 'PNG' CR LF 1A LF | 00 00 00 0D | 'IHDR' */
    val PNG_HEADER = byteArrayOf(
        0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
        0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52
    )
    private val RPGMV_MAGIC = "RPGMV".toByteArray(Charsets.US_ASCII)

    /** 'IEND' + its CRC: the last 8 bytes of every well-formed PNG. */
    private val PNG_IEND = byteArrayOf(
        0x49, 0x45, 0x4E, 0x44, 0xAE.toByte(), 0x42, 0x60, 0x82.toByte()
    )

    sealed class Result {
        data class Ok(val png: ByteArray) : Result()
        data class Fail(val reason: String) : Result()
    }

    /** In-memory restoration (used by tests and small inputs). */
    fun restore(input: ByteArray): Result {
        if (input.isEmpty()) return Result.Fail("Empty file")
        if (input.size <= FAKE_HEADER_LEN + PNG_HEAD_LEN) {
            return Result.Fail("File too small to be an encrypted PNG")
        }
        if (!input.startsWith(RPGMV_MAGIC)) {
            return Result.Fail("Missing RPGMV header (not an encrypted RPG Maker file)")
        }
        val out = ByteArray(input.size - FAKE_HEADER_LEN)
        PNG_HEADER.copyInto(out, 0)
        input.copyInto(out, PNG_HEAD_LEN, FAKE_HEADER_LEN + PNG_HEAD_LEN, input.size)
        return validate(out)?.let { Result.Fail(it) } ?: Result.Ok(out)
    }

    /**
     * Streaming restoration with constant memory. Returns null on success or a readable error.
     * On error the caller must discard whatever was written to [output].
     * [checkCancelled] is invoked between chunks and may throw to abort.
     */
    fun restoreStream(
        input: InputStream,
        output: OutputStream,
        checkCancelled: () -> Unit = {}
    ): String? {
        val head = ByteArray(FAKE_HEADER_LEN + PNG_HEAD_LEN)
        val n = readFully(input, head)
        if (n == 0) return "Empty file"
        if (n < head.size) return "File too small to be an encrypted PNG"
        if (!head.startsWith(RPGMV_MAGIC)) {
            return "Missing RPGMV header (not an encrypted RPG Maker file)"
        }
        output.write(PNG_HEADER)
        var written = PNG_HEAD_LEN.toLong()
        var tail = PNG_HEADER.copyOfRange(PNG_HEAD_LEN - TAIL_LEN, PNG_HEAD_LEN)
        val buf = ByteArray(64 * 1024)
        while (true) {
            checkCancelled()
            val r = input.read(buf)
            if (r < 0) break
            if (r == 0) continue
            output.write(buf, 0, r)
            written += r
            tail = if (r >= TAIL_LEN) {
                buf.copyOfRange(r - TAIL_LEN, r)
            } else {
                val joined = tail + buf.copyOf(r)
                joined.copyOfRange(joined.size - TAIL_LEN, joined.size)
            }
        }
        output.flush()
        if (written < MIN_PNG_SIZE) return "Too small for a PNG"
        if (!tail.contentEquals(PNG_IEND)) {
            return "Missing IEND chunk (file truncated or damaged)"
        }
        return null
    }

    /** Structural check of a complete PNG; null when OK. */
    fun validate(png: ByteArray): String? {
        if (png.size < MIN_PNG_SIZE) return "Too small for a PNG"
        if (!png.startsWith(PNG_HEADER.copyOf(8))) return "Bad PNG signature"
        if (!png.endsWith(PNG_IEND)) return "Missing IEND chunk (file truncated or damaged)"
        return null
    }

    private fun readFully(input: InputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val r = input.read(buf, total, buf.size - total)
            if (r < 0) break
            total += r
        }
        return total
    }

    private fun ByteArray.startsWith(p: ByteArray) =
        size >= p.size && p.indices.all { this[it] == p[it] }

    private fun ByteArray.endsWith(p: ByteArray) =
        size >= p.size && p.indices.all { this[size - p.size + it] == p[it] }
}
