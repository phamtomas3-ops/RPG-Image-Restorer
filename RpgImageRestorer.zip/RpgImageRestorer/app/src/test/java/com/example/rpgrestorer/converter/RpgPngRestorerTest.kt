package com.example.rpgrestorer.converter

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream

class RpgPngRestorerTest {
    private val fakeHeader = "RPGMV".toByteArray() + ByteArray(11)

    private fun fakePng(bodySize: Int = 100): ByteArray {
        val iend = byteArrayOf(0, 0, 0, 0, 0x49, 0x45, 0x4E, 0x44, 0xAE.toByte(), 0x42, 0x60, 0x82.toByte())
        return RpgPngRestorer.PNG_HEADER + ByteArray(bodySize) { (it % 251).toByte() } + iend
    }

    /** Mimics RPG Maker: fake header + first 16 bytes XOR-encrypted with [key]. */
    private fun encrypt(png: ByteArray, key: Int = 0x5A): ByteArray {
        val c = png.copyOf()
        for (i in 0 until 16) c[i] = (c[i].toInt() xor key).toByte()
        return fakeHeader + c
    }

    private fun streamRestore(data: ByteArray): Pair<String?, ByteArray> {
        val out = ByteArrayOutputStream()
        val error = RpgPngRestorer.restoreStream(ByteArrayInputStream(data), out)
        return error to out.toByteArray()
    }

    // ----- in-memory API -----

    @Test fun restoresOriginalPng() {
        val png = fakePng()
        val r = RpgPngRestorer.restore(encrypt(png))
        assertArrayEquals(png, (r as RpgPngRestorer.Result.Ok).png)
    }

    @Test fun independentOfEncryptionKey() {
        val png = fakePng()
        for (key in listOf(0x01, 0x7F, 0xFF, 0xA5)) {
            val r = RpgPngRestorer.restore(encrypt(png, key))
            assertArrayEquals(png, (r as RpgPngRestorer.Result.Ok).png)
        }
    }

    @Test fun rejectsEmpty() =
        assertTrue(RpgPngRestorer.restore(ByteArray(0)) is RpgPngRestorer.Result.Fail)

    @Test fun rejectsTooSmall() =
        assertTrue(RpgPngRestorer.restore(fakeHeader + ByteArray(10)) is RpgPngRestorer.Result.Fail)

    @Test fun rejectsUnencryptedPng() =
        assertTrue(RpgPngRestorer.restore(fakePng()) is RpgPngRestorer.Result.Fail)

    @Test fun rejectsTruncatedFile() {
        val e = encrypt(fakePng())
        assertTrue(RpgPngRestorer.restore(e.copyOf(e.size - 5)) is RpgPngRestorer.Result.Fail)
    }

    @Test fun handlesLargeImage() {
        val png = fakePng(8_000_000)
        val r = RpgPngRestorer.restore(encrypt(png))
        assertArrayEquals(png, (r as RpgPngRestorer.Result.Ok).png)
    }

    // ----- streaming API -----

    @Test fun streamMatchesInMemory() {
        val png = fakePng(70_000) // larger than the 64 KB copy buffer
        val (error, out) = streamRestore(encrypt(png))
        assertNull(error)
        assertArrayEquals(png, out)
    }

    @Test fun streamWorksWithTinyReads() {
        val png = fakePng(500)
        val slow = object : InputStream() {
            private val src = ByteArrayInputStream(encrypt(png))
            override fun read(): Int = src.read()
            override fun read(b: ByteArray, off: Int, len: Int): Int = src.read(b, off, minOf(len, 3))
        }
        val out = ByteArrayOutputStream()
        assertNull(RpgPngRestorer.restoreStream(slow, out))
        assertArrayEquals(png, out.toByteArray())
    }

    @Test fun streamRejectsEmptyAndGarbageAndTruncated() {
        assertEquals("Empty file", streamRestore(ByteArray(0)).first)
        assertTrue(streamRestore(fakePng()).first!!.contains("RPGMV"))
        val e = encrypt(fakePng())
        assertTrue(streamRestore(e.copyOf(e.size - 3)).first!!.contains("IEND"))
        assertTrue(streamRestore(ByteArray(20)).first!!.contains("small"))
    }

    @Test fun streamPropagatesCancellation() {
        class Stop : RuntimeException()
        try {
            RpgPngRestorer.restoreStream(ByteArrayInputStream(encrypt(fakePng())), ByteArrayOutputStream()) { throw Stop() }
            fail("expected cancellation to propagate")
        } catch (_: Stop) {
        }
    }

    @Test fun validateChecksSignatureAndIend() {
        assertNull(RpgPngRestorer.validate(fakePng()))
        val broken = fakePng().also { it[1] = 0 }
        assertTrue(RpgPngRestorer.validate(broken)!!.contains("signature"))
    }
}
