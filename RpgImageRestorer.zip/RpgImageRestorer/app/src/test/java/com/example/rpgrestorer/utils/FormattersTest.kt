package com.example.rpgrestorer.utils

import org.junit.Assert.assertEquals
import org.junit.Test

class FormattersTest {
    @Test fun formatsSizes() {
        assertEquals("0 B", formatSize(0))
        assertEquals("1023 B", formatSize(1023))
        assertEquals("1.0 KB", formatSize(1024))
        assertEquals("1.5 KB", formatSize(1536))
        assertEquals("5.0 MB", formatSize(5L * 1024 * 1024))
    }
}
