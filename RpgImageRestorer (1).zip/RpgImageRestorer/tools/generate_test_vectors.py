#!/usr/bin/env python3
"""
Independent generator of RPG Maker MV/MZ test vectors (does NOT share code with the Kotlin app).

Format, per the published rpg_core.js / rpg_core Decrypter and Petschko's decrypter:
  file    = HEADER(16) + data
  HEADER  = 5250474d56000000 (signature) + 000301 (version) + 0000000000 (remain)
  data    = original file with its FIRST 16 bytes XORed with the key
  key     = the 32-hex-character "encryptionKey" of System.json, read as 16 bytes
.png_ (MZ) and .rpgmvp (MV) have identical content; only the extension differs.

The PNG is built with Python's zlib (a real, decodable 16x16 RGBA image).
The key below is a TEST key made up for this repository; it belongs to no game.
Usage: python3 tools/generate_test_vectors.py app/src/test/resources/vectors
"""
import hashlib, struct, sys, zlib, os

KEY_HEX = "a3f1c97e5d2b48806ce1f7a9034bd25e"
out = sys.argv[1] if len(sys.argv) > 1 else "."
os.makedirs(out, exist_ok=True)

def chunk(tag, data):
    return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

W = H = 16
rows = b""
for y in range(H):
    rows += b"\x00" + b"".join(bytes([x * 16 % 256, y * 16 % 256, (x * y) % 256, 255 if (x + y) % 5 else 90]) for x in range(W))
png = (b"\x89PNG\r\n\x1a\n"
       + chunk(b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 6, 0, 0, 0))
       + chunk(b"IDAT", zlib.compress(rows, 9))
       + chunk(b"IEND", b""))

key = bytes(int(KEY_HEX[i:i + 2], 16) for i in range(0, 32, 2))
header = bytes.fromhex("5250474d56000000" "000301" "0000000000")
assert len(header) == 16 and len(key) == 16
enc = header + bytes(b ^ k for b, k in zip(png[:16], key)) + png[16:]

# self-check with a second, differently written decrypt
dec = bytearray(enc[16:])
for i in range(16):
    dec[i] ^= key[i]
assert bytes(dec) == png

def w(name, data):
    with open(os.path.join(out, name), "wb") as f:
        f.write(data)

w("sample.png", png)
w("sample.png_", enc)
w("sample.rpgmvp", enc)
w("key.txt", (KEY_HEX + "\n").encode())
w("sample.sha256", (hashlib.sha256(png).hexdigest() + "\n").encode())
print("png bytes:", len(png), "sha256:", hashlib.sha256(png).hexdigest())
print("encrypted first 48 bytes:", enc[:48].hex())
