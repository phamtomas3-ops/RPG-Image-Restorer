# RPG Image Restorer (Android) – v1.1.0

Offline, two-way converter for RPG Maker MV/MZ encrypted images.
**Decrypt** `.png_` / `.rpgmvp` → `.png`  ·  **Encrypt** `.png` → `.png_` / `.rpgmvp`.
No INTERNET permission, no analytics, no accounts. Files are accessed through the Storage Access Framework only.

## Build
Android Studio (Koala or newer), JDK 17, Android SDK 35.
1. **Open** this folder in Android Studio and let Gradle sync (Gradle 8.9, AGP 8.6.1; accept an upgrade prompt if offered).
2. **Build → Build APK(s)**, or `gradle wrapper --gradle-version 8.9` once and then `./gradlew assembleDebug`.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`.
4. Unit tests (no device needed): `./gradlew testDebugUnitTest`.

> **Honesty note:** this version was written and checked without a Kotlin compiler or Android SDK available, so a
> first build may surface small compile errors that I could not catch. None of the Kotlin (including the tests)
> has been executed yet. Please run the unit tests first; send me any error text and I will fix it.

## The format (what the code implements)
```
file = HEADER(16) + data
HEADER = 52 50 47 4D 56 00 00 00 | 00 03 01 | 00 00 00 00 00      ("RPGMV", version, remain)
data   = original file whose FIRST 16 BYTES are XORed with the key; everything after is unchanged
key    = "encryptionKey" in the game's System.json: 32 hex characters = 16 bytes
```
Sources used: Petschko's RPG-Maker-MV-Decrypter (header constants, MV `.rpgmvp` / MZ `.png_`, System.json
key location) and an independently written Rust decrypter library (XOR of the first 16 bytes, key from hex).
**MV vs MZ:** the container and algorithm are the same; only the extension differs (MV `.rpgmvp`, MZ `.png_`).
System.json is at `www/data/System.json` (MV) or `data/System.json` (MZ).

## Modes
- **Decrypt** – detects `.png_` and `.rpgmvp` by extension and verifies the `RPGMV` header. The key is optional:
  every PNG starts with the same 16 bytes, so images can be restored without a key. If you enter a key, it is
  used and **checked**: a wrong key is reported as "Wrong key", never silently replaced by the key-less method.
- **Encrypt** – the key is **required**. There is no built-in or default key. You choose `.png_` or `.rpgmvp`.

## Encryption key
Manual entry (32 hex characters, validated, masked, show/hide) · **From System.json** (reads `encryptionKey`) ·
**From encrypted image** (derives the key from any `.png_`/`.rpgmvp` of that game, using the fact that all PNGs
start with identical 16 bytes). The key lives in memory only: it is not saved, logged, put in recents, or sent anywhere,
and is forgotten when the app closes. Only use keys from games you own or are authorized to modify.

## Safety and verification
- Originals are never modified; outputs always differ in extension and get unique names. Existing files are
  kept (numbered), skipped, or – only if you confirm in Settings – replaced.
- Decrypt output is checked (PNG signature, IEND trailer, real `BitmapFactory` decode).
- Encrypt input must be a decodable PNG; the written file is re-read and must decrypt back to a PNG with an
  identical SHA-256 to the source. Failures are discarded and reported per file.
- Files are streamed (constant memory, 64 KB buffers, 3 files in parallel); cancellation cleans up partial output.
  Only file *names* are held for a batch, never file contents.

## Tests
`tools/generate_test_vectors.py` is an independent Python implementation (stdlib `zlib`) that creates
`app/src/test/resources/vectors/` (a real PNG, its `.png_`/`.rpgmvp` encryption, test key, SHA-256).
Kotlin tests cover: `.png_` and `.rpgmvp` decryption, both encryptions (byte-exact against the Python vectors and a
hard-coded known-answer hex), round trips with several keys, wrong keys, invalid/empty/truncated/header-only files,
key parsing and derivation, a 64 MB streamed file, cancellation, filename sanitising, and output-name collisions
(including 300 parallel allocations). The test key is made up for this repository and belongs to no game.

## Limitations (please read)
- **Not verified against a real game or the RPG Maker runtime.** The vectors come from my reading of the published
  format, not from an actual RPG Maker project. Do not assume a specific game accepts the output until you have tried it.
- Games can change the header values in `rpg_core.js` / `rmmz_core.js` (rare). Encrypt always writes the default
  header above, so such games are unsupported for encryption. Decrypt only checks for `RPGMV`.
- The game must be configured to expect encrypted images (`hasEncryptedImages` in System.json) and the extension must
  match its engine version; this app does not edit game files.
- Only images are supported. Audio (`.rpgmvo/.rpgmvm`, `.ogg_/.m4a_`) uses the same container but is not handled.
- PNGs with a non-standard first chunk (e.g. Apple "CgBI") are rejected for encryption.
- Without a chosen output folder, results stay in app storage until the next batch (use ZIP or Share).
- A running batch stops if Android kills the app (no foreground service).
- Key-from-image derivation assumes a standard encrypted PNG; a wrong file gives a wrong key, which then fails the
  wrong-key check when used to decrypt.

## Layout
`converter/` format + crypto engine (pure Kotlin) · `data/` SAF scanning, output targets, name allocation, batch
processor, key sources, ZIP, share · `models/` · `utils/` · `ui/` Compose theme, components, screens, ViewModel.

## Attribution
Format knowledge from Petschko's RPG-Maker-MV-Decrypter (https://petschko.org/tools/mv_decrypter) and public
documentation. This is an independent implementation; no source code was copied. Check that project's license
before redistributing anything derived from it.
