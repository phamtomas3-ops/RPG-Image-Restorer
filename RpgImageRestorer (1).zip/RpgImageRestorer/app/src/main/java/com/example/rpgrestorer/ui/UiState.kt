package com.example.rpgrestorer.ui

import android.net.Uri
import com.example.rpgrestorer.converter.EncryptionKey
import com.example.rpgrestorer.converter.KeyParse
import com.example.rpgrestorer.models.ConversionItem
import com.example.rpgrestorer.models.ConversionMode
import com.example.rpgrestorer.models.EncryptedFormat
import com.example.rpgrestorer.models.ExistingFilePolicy
import com.example.rpgrestorer.models.InputFile
import com.example.rpgrestorer.models.RecentConversion
import com.example.rpgrestorer.models.Screen
import com.example.rpgrestorer.models.ThemeMode

data class UiState(
    val screen: Screen = Screen.HOME,
    val items: List<ConversionItem> = emptyList(),
    val running: Boolean = false,
    val outputTree: Uri? = null,
    val policy: ExistingFilePolicy = ExistingFilePolicy.RENAME,
    val theme: ThemeMode = ThemeMode.DARK,
    val recents: List<RecentConversion> = emptyList(),
    /** Non-null while a short blocking task (scan / ZIP / share preparation) is running. */
    val busyMessage: String? = null,

    // --- operation setup (home screen) ---
    val mode: ConversionMode = ConversionMode.DECRYPT,
    val format: EncryptedFormat = EncryptedFormat.PNG_UNDERSCORE,
    /** Held in memory only. Never persisted, logged or added to recents. */
    val keyText: String = "",
    val pending: List<InputFile> = emptyList(),
    val pendingLabel: String? = null,
    /** Operation of the batch whose items are shown on the converting / results screens. */
    val batchMode: ConversionMode = ConversionMode.DECRYPT
) {
    val keyParse: KeyParse get() = EncryptionKey.parse(keyText)

    /** Encrypt needs a valid key; Decrypt accepts no key (key-less) or a valid one, never an invalid one. */
    val keyOk: Boolean
        get() = when (mode) {
            ConversionMode.ENCRYPT -> keyParse is KeyParse.Valid
            ConversionMode.DECRYPT -> keyParse !is KeyParse.Invalid
        }

    val canStart: Boolean
        get() = pending.isNotEmpty() && !running && busyMessage == null && keyOk
}
