package com.example.rpgrestorer.data

import com.example.rpgrestorer.models.ExistingFilePolicy

/** Shared allocation logic; subclasses only know how to list, create and delete files. */
abstract class BaseOutputTarget : OutputTarget {
    private val allocator = NameAllocator { listExisting() }

    protected abstract fun listExisting(): List<String>
    protected abstract fun createFile(name: String, mimeType: String): OutputSlot
    protected abstract fun deleteExisting(actualName: String)

    override suspend fun create(
        desiredName: String,
        policy: ExistingFilePolicy,
        mimeType: String
    ): OutputSlot? {
        val allocation = allocator.allocate(desiredName, policy) ?: return null
        allocation.replaceExisting?.let { deleteExisting(it) }
        return createFile(allocation.name, mimeType)
    }
}
