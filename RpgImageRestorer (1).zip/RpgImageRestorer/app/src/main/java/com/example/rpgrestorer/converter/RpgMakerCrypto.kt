package com.example.rpgrestorer.converter

import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

/**
 * Streaming RPG Maker MV/MZ image encryption and decryption (.rpgmvp / .png_).
 * Pure Kotlin/JVM, constant memory. Every function returns null on success or a readable error;
 * on error the caller must discard whatever was written to the output.
 */
object RpgMakerCrypto {
    private const val CHUNK = 64 * 1024
    private const val TAIL_LEN = 8

    /**
     * Decrypts into a PNG. With [key] == null the 16 encrypted bytes are replaced by the constant PNG header
     * (works for every PNG). With a key they are XORed, and a key that does not yield a PNG header is
     * reported as wrong, never silently replaced.
     * [digest], if given, receives every byte of the produced PNG.
     */
    fun decrypt(
        input: InputStream,
        output: OutputStream,
        key: EncryptionKey?,
        digest: MessageDigest? = null,
        checkCancelled: () -> Unit = {}
    ): String? {
        val head = ByteArray(RpgFormat.HEADER_LEN + RpgFormat.KEY_LEN)
        val n = readFully(input, head)
        if (n == 0) return "Empty file"
        if (n < head.size) return "File too small to be an encrypted PNG"
        if (!head.startsWithBytes(RpgFormat.MAGIC)) {
            return "Missing RPGMV header (not an encrypted RPG Maker file)"
        }
        val first = head.copyOfRange(RpgFormat.HEADER_LEN, head.size)
        if (key == null) {
            RpgFormat.PNG_HEADER.copyInto(first)
        } else {
            key.xorInPlace(first)
            if (!first.contentEquals(RpgFormat.PNG_HEADER)) {
                return "Wrong key: the decrypted data is not a PNG, so this key does not match this file."
            }
        }
        output.write(first)
        digest?.update(first)
        return finish(input, output, digest, checkCancelled)
    }

    /**
     * Encrypts a PNG: writes the 16-byte RPG Maker header, the first 16 PNG bytes XORed with [key], then the
     * rest unchanged. [digest], if given, receives every byte of the source PNG.
     */
    fun encrypt(
        input: InputStream,
        output: OutputStream,
        key: EncryptionKey,
        digest: MessageDigest? = null,
        checkCancelled: () -> Unit = {}
    ): String? {
        val head = ByteArray(RpgFormat.KEY_LEN)
        val n = readFully(input, head)
        if (n == 0) return "Empty file"
        if (n < head.size) return "File too small to be a PNG"
        if (!head.contentEquals(RpgFormat.PNG_HEADER)) {
            return if (head.startsWithBytes(RpgFormat.PNG_HEADER.copyOf(8))) {
                "Unsupported PNG layout (first chunk is not a standard IHDR)"
            } else {
                "Not a PNG file (bad signature)"
            }
        }
        digest?.update(head)
        key.xorInPlace(head)
        output.write(RpgFormat.HEADER)
        output.write(head)
        return finish(input, output, digest, checkCancelled)
    }

    /**
     * Re-reads an encrypted file and proves it decrypts, with [key], to exactly the PNG whose SHA-256 is
     * [expectedSha256]. Streaming; nothing is held in memory.
     */
    fun verifyEncrypted(
        encrypted: InputStream,
        key: EncryptionKey,
        expectedSha256: ByteArray,
        checkCancelled: () -> Unit = {}
    ): String? {
        val md = MessageDigest.getInstance("SHA-256")
        val sink = object : OutputStream() {
            override fun write(b: Int) = Unit
            override fun write(b: ByteArray, off: Int, len: Int) = Unit
        }
        val error = decrypt(encrypted, sink, key, md, checkCancelled)
        if (error != null) return "Verification failed: $error"
        if (!md.digest().contentEquals(expectedSha256)) {
            return "Verification failed: the output does not decrypt back to the source image"
        }
        return null
    }

    /** Derives the key from an encrypted PNG (known plaintext: every PNG starts with the same 16 bytes). */
    fun deriveKey(encryptedHead: ByteArray): EncryptionKey? {
        if (encryptedHead.size < RpgFormat.HEADER_LEN + RpgFormat.KEY_LEN) return null
        if (!encryptedHead.startsWithBytes(RpgFormat.MAGIC)) return null
        val raw = ByteArray(RpgFormat.KEY_LEN) { i ->
            (encryptedHead[RpgFormat.HEADER_LEN + i].toInt() xor RpgFormat.PNG_HEADER[i].toInt()).toByte()
        }
        return EncryptionKey.fromBytes(raw)
    }

    /** Copies the unchanged remainder, then checks the result ends like a PNG. */
    private fun finish(
        input: InputStream,
        output: OutputStream,
        digest: MessageDigest?,
        checkCancelled: () -> Unit
    ): String? {
        var written = RpgFormat.KEY_LEN.toLong()
        var tail = RpgFormat.PNG_HEADER.copyOfRange(RpgFormat.KEY_LEN - TAIL_LEN, RpgFormat.KEY_LEN)
        val buf = ByteArray(CHUNK)
        while (true) {
            checkCancelled()
            val r = input.read(buf)
            if (r < 0) break
            if (r == 0) continue
            output.write(buf, 0, r)
            digest?.update(buf, 0, r)
            written += r
            tail = if (r >= TAIL_LEN) {
                buf.copyOfRange(r - TAIL_LEN, r)
            } else {
                val joined = tail + buf.copyOf(r)
                joined.copyOfRange(joined.size - TAIL_LEN, joined.size)
            }
        }
        output.flush()
        if (written < RpgFormat.MIN_PNG_SIZE) return "Too small for a PNG"
        if (!tail.contentEquals(RpgFormat.PNG_IEND)) {
            return "Missing IEND chunk (file truncated or damaged)"
        }
        return null
    }

    private fun readFully(input: InputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val r = input.read(buf, total, buf.size - total)
            if (r < 0) break
            total += r
        }
        return total
    }
}
