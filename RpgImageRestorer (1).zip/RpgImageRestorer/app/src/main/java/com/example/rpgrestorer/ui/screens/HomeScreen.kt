package com.example.rpgrestorer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.rpgrestorer.models.ConversionMode
import com.example.rpgrestorer.models.doneCount
import com.example.rpgrestorer.models.failedCount
import com.example.rpgrestorer.models.successCount
import com.example.rpgrestorer.ui.UiState
import com.example.rpgrestorer.ui.components.AppLogo
import com.example.rpgrestorer.ui.components.FormatCard
import com.example.rpgrestorer.ui.components.KeyCard
import com.example.rpgrestorer.ui.components.ModeSelector
import com.example.rpgrestorer.ui.components.RecentRow
import com.example.rpgrestorer.ui.components.SectionCard
import com.example.rpgrestorer.utils.folderLabel

@Composable
fun HomeScreen(
    state: UiState,
    actions: HomeActions,
    modifier: Modifier = Modifier
) {
    val encrypting = state.mode == ConversionMode.ENCRYPT
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AppLogo()
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("RPG Image Restorer", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Offline · no accounts · no network",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = actions.onOpenSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings")
                }
            }
        }
        item { ModeSelector(state.mode, actions.onMode) }
        item {
            SectionCard {
                Text(
                    if (encrypting) "Encrypt PNG images" else "Restore encrypted images",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    if (encrypting) "Pick .png files or a folder. They are encrypted on this device into RPG Maker format."
                    else "Pick .png_ / .rpgmvp files or a game folder. They are converted into normal PNGs on this device.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Button(
                    onClick = actions.onSelectFiles,
                    modifier = Modifier.fillMaxWidth().height(60.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(10.dp))
                    Text("Select files", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(12.dp))
                FilledTonalButton(
                    onClick = actions.onSelectFolder,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.List, contentDescription = null)
                    Spacer(Modifier.width(10.dp))
                    Text("Select folder")
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        state.pendingLabel ?: "Nothing selected yet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (state.pending.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant
                        else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    if (state.pending.isNotEmpty()) {
                        TextButton(onClick = actions.onClearSelection) { Text("Clear") }
                    }
                }
            }
        }
        if (encrypting) {
            item { FormatCard(state.format, actions.onFormat) }
        }
        item {
            KeyCard(
                keyText = state.keyText,
                parse = state.keyParse,
                required = encrypting,
                onChange = actions.onKeyChange,
                onFromSystemJson = actions.onKeyFromSystemJson,
                onFromEncryptedImage = actions.onKeyFromEncryptedImage
            )
        }
        item {
            SectionCard {
                Text("Save converted files to", style = MaterialTheme.typography.labelLarge)
                Text(
                    state.outputTree?.let { folderLabel(it) }
                        ?: "App storage (use ZIP or Share to keep them)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Row {
                    TextButton(onClick = actions.onChangeOutput) { Text("Choose folder") }
                    if (state.outputTree != null) {
                        TextButton(onClick = actions.onResetOutput) { Text("Use app storage") }
                    }
                }
            }
        }
        item {
            Button(
                onClick = actions.onStart,
                enabled = state.canStart,
                modifier = Modifier.fillMaxWidth().height(60.dp),
                shape = RoundedCornerShape(20.dp)
            ) {
                val count = state.pending.size
                Text(
                    "${state.mode.title} ${if (count > 0) "$count file(s)" else ""}".trim(),
                    style = MaterialTheme.typography.titleMedium
                )
            }
            if (state.pending.isNotEmpty() && !state.keyOk) {
                Text(
                    if (encrypting) "Enter a valid key to enable encryption." else "Fix or clear the key to continue.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
        if (state.items.isNotEmpty() && !state.running) {
            item {
                val total = state.items.size
                SectionCard {
                    Text("Last batch", style = MaterialTheme.typography.titleMedium)
                    LinearProgressIndicator(
                        progress = { state.items.successCount / total.toFloat() },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp).height(8.dp)
                    )
                    Text(
                        "${state.items.successCount} converted · ${state.items.failedCount} failed · " +
                            "${state.items.doneCount} of $total processed",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = actions.onOpenResults) { Text("View results") }
                }
            }
        }
        item { Text("Recent conversions", style = MaterialTheme.typography.titleMedium) }
        if (state.recents.isEmpty()) {
            item {
                Text(
                    "Nothing yet. Your finished batches will appear here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(state.recents) { RecentRow(it) }
        }
    }
}
