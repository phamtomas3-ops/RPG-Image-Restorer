package com.example.rpgrestorer.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.rpgrestorer.converter.KeyParse

/** Masked key field with validation and two local ways to fill it in. The key is never stored. */
@Composable
fun KeyCard(
    keyText: String,
    parse: KeyParse,
    required: Boolean,
    onChange: (String) -> Unit,
    onFromSystemJson: () -> Unit,
    onFromEncryptedImage: () -> Unit,
    modifier: Modifier = Modifier
) {
    var visible by remember { mutableStateOf(false) }
    SectionCard(modifier) {
        Text(
            if (required) "Encryption key (required)" else "Encryption key (optional)",
            style = MaterialTheme.typography.titleMedium
        )
        OutlinedTextField(
            value = keyText,
            onValueChange = onChange,
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            singleLine = true,
            label = { Text("32 hex characters") },
            isError = parse is KeyParse.Invalid,
            visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            trailingIcon = {
                TextButton(onClick = { visible = !visible }) { Text(if (visible) "Hide" else "Show") }
            },
            supportingText = {
                when (parse) {
                    is KeyParse.Invalid -> Text(parse.reason)
                    is KeyParse.Valid -> Text("Valid 128-bit key")
                    KeyParse.Empty -> Text(
                        if (required) "Paste the key, or load it from your game below."
                        else "Leave empty to restore without a key. Enter one to also verify it."
                    )
                }
            }
        )
        Row {
            TextButton(onClick = onFromSystemJson) { Text("From System.json") }
            TextButton(onClick = onFromEncryptedImage) { Text("From encrypted image") }
        }
        if (keyText.isNotEmpty()) {
            TextButton(onClick = { onChange("") }) { Text("Clear key") }
        }
        Text(
            "The key is only held in memory on this device and is forgotten when the app closes. " +
                "Use keys only from games you own or are authorized to modify.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
