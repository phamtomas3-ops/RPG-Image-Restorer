package com.example.rpgrestorer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rpgrestorer.models.ConversionItem
import com.example.rpgrestorer.models.ConversionMode
import com.example.rpgrestorer.models.ConversionStatus
import com.example.rpgrestorer.models.OutputInfo
import com.example.rpgrestorer.ui.components.ItemRow
import com.example.rpgrestorer.ui.components.ResultCard
import com.example.rpgrestorer.ui.components.ScreenHeader
import com.example.rpgrestorer.ui.components.SectionCard

@Composable
fun ResultsScreen(
    batch: List<ConversionItem>,
    mode: ConversionMode,
    onBack: () -> Unit,
    onSaveZip: () -> Unit,
    onShareAll: () -> Unit,
    onShareOne: (OutputInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    val restored = batch.filter { it.status is ConversionStatus.Success && it.output != null }
    val problems = batch.filter { it.status !is ConversionStatus.Success }
    val keptInAppStorage = restored.firstOrNull()?.output?.uri?.scheme == "file"

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "header") { ScreenHeader("Results", onBack = onBack) }
        item(key = "actions") {
            SectionCard {
                Text(
                    "${restored.size} of ${batch.size} " + if (mode == ConversionMode.ENCRYPT) "files encrypted" else "images restored",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    if (keptInAppStorage) {
                        "Kept in app storage until your next batch. Save a ZIP or share to keep them."
                    } else {
                        "Saved to your chosen output folder."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )
                Row {
                    Button(
                        onClick = onShareAll,
                        enabled = restored.isNotEmpty(),
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Share all")
                    }
                    Spacer(Modifier.width(12.dp))
                    FilledTonalButton(
                        onClick = onSaveZip,
                        enabled = restored.isNotEmpty(),
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = RoundedCornerShape(18.dp)
                    ) { Text("Save ZIP") }
                }
                TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Start a new batch") }
            }
        }
        if (restored.isNotEmpty()) {
            item(key = "restored-title") {
                Text((if (mode == ConversionMode.ENCRYPT) "Encrypted" else "Restored") + " (${restored.size})", style = MaterialTheme.typography.titleMedium)
            }
            items(restored, key = { it.id }) { item ->
                val out = item.output
                if (out != null) {
                    // Encrypted files cannot be previewed, so show the source PNG instead.
                    val preview = if (mode == ConversionMode.ENCRYPT) item.input.uri else out.uri
                    ResultCard(item.input.name, out, preview, onShare = { onShareOne(out) })
                }
            }
        }
        if (problems.isNotEmpty()) {
            item(key = "problems-title") {
                Text("Not converted (${problems.size})", style = MaterialTheme.typography.titleMedium)
            }
            items(problems, key = { it.id }) { ItemRow(it) }
        }
    }
}
