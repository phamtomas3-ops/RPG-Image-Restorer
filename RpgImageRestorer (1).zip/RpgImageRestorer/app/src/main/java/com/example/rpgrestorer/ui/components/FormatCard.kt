package com.example.rpgrestorer.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rpgrestorer.models.EncryptedFormat

/** Target-format picker shown in Encrypt mode. */
@Composable
fun FormatCard(
    selected: EncryptedFormat,
    onSelected: (EncryptedFormat) -> Unit,
    modifier: Modifier = Modifier
) {
    SectionCard(modifier) {
        Text("Target format", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EncryptedFormat.entries.forEach { format ->
                FilterChip(
                    selected = format == selected,
                    onClick = { onSelected(format) },
                    label = { Text("${format.extension}  ·  ${format.hint}") }
                )
            }
        }
        Text(
            "Both formats use the same encryption. Pick the extension your game version loads. " +
                "Compatibility with a specific game is not verified by this app.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 10.dp)
        )
    }
}
