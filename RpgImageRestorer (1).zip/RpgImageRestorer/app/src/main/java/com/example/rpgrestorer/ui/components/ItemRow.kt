package com.example.rpgrestorer.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.rpgrestorer.models.ConversionItem
import com.example.rpgrestorer.models.ConversionStatus

private fun ConversionStatus.label(): String = when (this) {
    ConversionStatus.Pending -> "Waiting"
    ConversionStatus.Running -> "Restoring…"
    ConversionStatus.Success -> "Done"
    is ConversionStatus.Failed -> reason
    is ConversionStatus.Skipped -> reason
    ConversionStatus.Cancelled -> "Cancelled"
}

/** One line per file with its individual status. */
@Composable
fun ItemRow(item: ConversionItem, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StatusIcon(item.status)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.input.name,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                item.status.label(),
                style = MaterialTheme.typography.bodySmall,
                color = if (item.status is ConversionStatus.Failed) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
