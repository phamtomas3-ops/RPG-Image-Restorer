package com.example.rpgrestorer.data

import com.example.rpgrestorer.models.ExistingFilePolicy
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Pure (Android-free) output-name allocation, serialized so parallel conversions never collide:
 *  - duplicates inside the same batch always get a numeric suffix,
 *  - files that existed before the batch follow the user's [ExistingFilePolicy].
 */
class NameAllocator(private val listExisting: () -> List<String>) {

    /** [replaceExisting] is the actual name of a pre-existing file to delete first (OVERWRITE only). */
    class Allocation(val name: String, val replaceExisting: String?)

    private val lock = Mutex()
    private var preexisting: Map<String, String>? = null // lower-case -> actual name
    private val allocated = HashSet<String>()            // lower-case names used by this batch

    /** Returns null when [policy] is SKIP and the name already existed before the batch. */
    suspend fun allocate(desiredName: String, policy: ExistingFilePolicy): Allocation? = lock.withLock {
        val existing = preexisting
            ?: listExisting().associateBy { it.lowercase() }.also { preexisting = it }
        var name = desiredName
        var replace: String? = null
        val key = name.lowercase()
        if (key in allocated) {
            name = uniqueName(desiredName, existing)
        } else if (key in existing) {
            when (policy) {
                ExistingFilePolicy.SKIP -> return@withLock null
                ExistingFilePolicy.RENAME -> name = uniqueName(desiredName, existing)
                ExistingFilePolicy.OVERWRITE -> replace = existing.getValue(key)
            }
        }
        allocated += name.lowercase()
        Allocation(name, replace)
    }

    private fun uniqueName(base: String, existing: Map<String, String>): String {
        var n = 1
        var candidate = com.example.rpgrestorer.utils.FileNames.withSuffix(base, n)
        while (candidate.lowercase() in allocated || candidate.lowercase() in existing) {
            n++
            candidate = com.example.rpgrestorer.utils.FileNames.withSuffix(base, n)
        }
        return candidate
    }
}
