package com.example.rpgrestorer.models

import com.example.rpgrestorer.converter.EncryptionKey

enum class ConversionMode(val title: String) {
    DECRYPT("Decrypt"),
    ENCRYPT("Encrypt")
}

/** Both extensions use the identical container; the extension must match what the game engine loads. */
enum class EncryptedFormat(val extension: String, val hint: String) {
    PNG_UNDERSCORE(".png_", "RPG Maker MZ"),
    RPGMVP(".rpgmvp", "RPG Maker MV")
}

/** Everything the batch processor needs to know about the requested conversion. */
data class ConversionPlan(
    val mode: ConversionMode,
    val format: EncryptedFormat,
    val key: EncryptionKey?
) {
    init {
        require(mode == ConversionMode.DECRYPT || key != null) { "Encrypting requires a key" }
    }
}
