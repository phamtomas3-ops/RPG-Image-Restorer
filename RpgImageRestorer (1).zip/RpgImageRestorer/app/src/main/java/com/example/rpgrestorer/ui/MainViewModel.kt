package com.example.rpgrestorer.ui

import android.app.Application
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.rpgrestorer.converter.KeyParse
import com.example.rpgrestorer.data.BatchProcessor
import com.example.rpgrestorer.data.FileScanner
import com.example.rpgrestorer.data.KeySources
import com.example.rpgrestorer.data.LocalDirTarget
import com.example.rpgrestorer.data.OutputTarget
import com.example.rpgrestorer.data.RecentStore
import com.example.rpgrestorer.data.SettingsStore
import com.example.rpgrestorer.data.ShareHelper
import com.example.rpgrestorer.data.TreeTarget
import com.example.rpgrestorer.data.ZipExporter
import com.example.rpgrestorer.models.ConversionItem
import com.example.rpgrestorer.models.ConversionMode
import com.example.rpgrestorer.models.ConversionPlan
import com.example.rpgrestorer.models.ConversionStatus
import com.example.rpgrestorer.models.EncryptedFormat
import com.example.rpgrestorer.models.ExistingFilePolicy
import com.example.rpgrestorer.models.InputFile
import com.example.rpgrestorer.models.OutputInfo
import com.example.rpgrestorer.models.RecentConversion
import com.example.rpgrestorer.models.Screen
import com.example.rpgrestorer.models.ThemeMode
import com.example.rpgrestorer.models.failedCount
import com.example.rpgrestorer.models.skippedCount
import com.example.rpgrestorer.models.successCount
import com.example.rpgrestorer.models.successful
import com.example.rpgrestorer.utils.FileNames
import com.example.rpgrestorer.utils.folderLabel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val context: Context = app.applicationContext
    private val resolver: ContentResolver = app.contentResolver
    private val settings = SettingsStore(context)
    private val recentStore = RecentStore(context)
    private val scanner = FileScanner(resolver)
    private val keySources = KeySources(resolver)
    private val processor = BatchProcessor(resolver)
    private val restoredRoot = File(context.filesDir, "restored")

    private val _state = MutableStateFlow(
        UiState(
            outputTree = settings.outputTree,
            policy = settings.policy,
            theme = settings.theme,
            recents = recentStore.load()
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _events = Channel<UiEvent>(Channel.BUFFERED)
    val events: Flow<UiEvent> = _events.receiveAsFlow()

    private var batchJob: Job? = null

    // ---------- operation setup ----------

    fun setMode(mode: ConversionMode) {
        if (_state.value.running || _state.value.mode == mode) return
        // A folder scan depends on the mode (.png vs .png_/.rpgmvp), so the old selection is dropped.
        _state.update { it.copy(mode = mode, pending = emptyList(), pendingLabel = null) }
    }

    fun setFormat(format: EncryptedFormat) = _state.update { it.copy(format = format) }

    fun setKeyText(text: String) = _state.update { it.copy(keyText = text.take(MAX_KEY_INPUT)) }

    fun clearKey() = _state.update { it.copy(keyText = "") }

    fun clearSelection() = _state.update { it.copy(pending = emptyList(), pendingLabel = null) }

    fun onKeyFilePicked(uri: Uri, fromSystemJson: Boolean) {
        if (_state.value.busyMessage != null) return
        _state.update { it.copy(busyMessage = "Reading key…") }
        viewModelScope.launch {
            try {
                val key = withContext(Dispatchers.IO) {
                    if (fromSystemJson) keySources.fromSystemJson(uri) else keySources.fromEncryptedImage(uri)
                }
                _state.update { it.copy(keyText = key.toHex()) }
                postMessage("Key loaded. It stays on this device and is not saved.")
            } catch (e: Exception) {
                postMessage(e.message ?: "Could not read a key from that file")
            } finally {
                _state.update { it.copy(busyMessage = null) }
            }
        }
    }

    // ---------- picking ----------

    fun onFilesPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        scanSelection("Reading selection…", { "${it.size} file(s) selected" }) { scanner.describe(uris) }
    }

    fun onFolderPicked(tree: Uri) {
        val mode = _state.value.mode
        scanSelection("Scanning folder…", { "${it.size} file(s) found in ${folderLabel(tree)}" }) {
            scanner.scanTree(tree) { name -> FileNames.isInputFor(mode, name) }
        }
    }

    private fun scanSelection(message: String, label: (List<InputFile>) -> String, scan: () -> List<InputFile>) {
        val s = _state.value
        if (s.running || s.busyMessage != null) return
        _state.update { it.copy(busyMessage = message) }
        viewModelScope.launch {
            try {
                val files = withContext(Dispatchers.IO) { scan() }
                if (files.isEmpty()) {
                    postMessage(
                        if (_state.value.mode == ConversionMode.DECRYPT) "No .png_ or .rpgmvp files found."
                        else "No .png files found."
                    )
                } else {
                    _state.update { it.copy(pending = files, pendingLabel = label(files)) }
                }
            } catch (e: Exception) {
                postMessage("Could not read the selection: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                _state.update { it.copy(busyMessage = null) }
            }
        }
    }

    // ---------- conversion ----------

    fun startConversion() {
        val s = _state.value
        if (!s.canStart) {
            postMessage(
                when {
                    s.mode == ConversionMode.ENCRYPT && s.keyParse !is KeyParse.Valid ->
                        "Enter a valid 32-character encryption key first."
                    s.keyParse is KeyParse.Invalid -> "The key is invalid. Fix it or clear the field."
                    else -> "Select files or a folder first."
                }
            )
            return
        }
        val key = (s.keyParse as? KeyParse.Valid)?.key
        val plan = ConversionPlan(s.mode, s.format, key) // throws only if the checks above were bypassed
        val items = s.pending.mapIndexed { index, file -> ConversionItem(id = index, input = file) }
        _state.update {
            it.copy(
                items = items, screen = Screen.CONVERTING, running = true,
                batchMode = plan.mode, pending = emptyList(), pendingLabel = null
            )
        }
        batchJob = viewModelScope.launch { runBatch(items, plan) }
    }

    private suspend fun runBatch(items: List<ConversionItem>, plan: ConversionPlan) {
        var cancelled = false
        try {
            val target = withContext(Dispatchers.IO) { resolveTarget() }
            processor.run(items, target, _state.value.policy, plan) { updated ->
                _state.update { s ->
                    s.copy(items = s.items.toMutableList().also { list -> list[updated.id] = updated })
                }
            }
        } catch (e: CancellationException) {
            cancelled = true
        } catch (e: Exception) {
            postMessage("Conversion stopped: ${e.message ?: e.javaClass.simpleName}")
        }
        finishBatch(cancelled, plan.mode)
    }

    private fun resolveTarget(): OutputTarget {
        restoredRoot.deleteRecursively() // results of the previous batch are replaced
        val tree = settings.outputTree
        if (tree != null) {
            val writable = resolver.persistedUriPermissions.any { it.uri == tree && it.isWritePermission }
            if (writable) return TreeTarget(resolver, tree)
            settings.outputTree = null
            _state.update { it.copy(outputTree = null) }
            postMessage("The output folder is no longer accessible. Using app storage instead.")
        }
        return LocalDirTarget(File(restoredRoot, "batch_${System.currentTimeMillis()}"))
    }

    private fun finishBatch(cancelled: Boolean, mode: ConversionMode) {
        val finalItems = _state.value.items.map {
            if (it.status is ConversionStatus.Pending || it.status is ConversionStatus.Running) {
                it.copy(status = ConversionStatus.Cancelled)
            } else it
        }
        val ok = finalItems.successCount
        val failed = finalItems.failedCount + finalItems.skippedCount
        var recents = _state.value.recents
        if (ok + failed > 0) {
            val first = finalItems.first().input.name
            val names = if (finalItems.size == 1) first else "$first and ${finalItems.size - 1} more"
            recents = recentStore.add(
                RecentConversion(System.currentTimeMillis(), finalItems.size, ok, failed, "${mode.title} · $names")
            )
        }
        _state.update {
            it.copy(
                items = finalItems,
                running = false,
                recents = recents,
                screen = if (cancelled && ok == 0) Screen.HOME else Screen.RESULTS
            )
        }
        if (cancelled) postMessage("Conversion cancelled. $ok file(s) were already converted.")
    }

    fun cancelBatch() {
        batchJob?.cancel()
    }

    // ---------- navigation ----------

    fun openSettings() = _state.update { it.copy(screen = Screen.SETTINGS) }
    fun openResults() = _state.update { it.copy(screen = Screen.RESULTS) }
    fun goHome() = _state.update { it.copy(screen = Screen.HOME) }

    fun onBack() {
        when (_state.value.screen) {
            Screen.CONVERTING -> cancelBatch()
            Screen.RESULTS, Screen.SETTINGS -> goHome()
            Screen.HOME -> Unit
        }
    }

    // ---------- settings ----------

    fun setTheme(mode: ThemeMode) {
        settings.theme = mode
        _state.update { it.copy(theme = mode) }
    }

    fun setPolicy(policy: ExistingFilePolicy) {
        settings.policy = policy
        _state.update { it.copy(policy = policy) }
    }

    fun onOutputFolderPicked(tree: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try {
            resolver.takePersistableUriPermission(tree, flags)
        } catch (e: SecurityException) {
            postMessage("Could not keep access to that folder. Please pick it again.")
            return
        }
        releaseOutputPermission()
        settings.outputTree = tree
        _state.update { it.copy(outputTree = tree) }
    }

    fun resetOutputFolder() {
        releaseOutputPermission()
        settings.outputTree = null
        _state.update { it.copy(outputTree = null) }
    }

    private fun releaseOutputPermission() {
        val old = settings.outputTree ?: return
        try {
            resolver.releasePersistableUriPermission(
                old, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            // already released
        }
    }

    fun clearRecents() {
        recentStore.clear()
        _state.update { it.copy(recents = emptyList()) }
    }

    fun clearStoredResults() {
        if (_state.value.running) return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { restoredRoot.deleteRecursively() }
            _state.update { s -> s.copy(items = s.items.filter { it.output?.uri?.scheme != "file" }) }
            postMessage("Stored results cleared.")
        }
    }

    // ---------- export & share ----------

    fun shareAll() = share(_state.value.items.successful)

    fun shareOne(image: OutputInfo) = share(listOf(image))

    private fun share(images: List<OutputInfo>) {
        if (images.isEmpty() || _state.value.busyMessage != null) return
        val mime = if (_state.value.batchMode == ConversionMode.ENCRYPT) "application/octet-stream" else "image/png"
        _state.update { it.copy(busyMessage = "Preparing files to share…") }
        viewModelScope.launch {
            try {
                val intent = withContext(Dispatchers.IO) { ShareHelper.buildIntent(context, images, mime) }
                _events.send(UiEvent.Share(intent))
            } catch (e: Exception) {
                postMessage("Could not share: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                _state.update { it.copy(busyMessage = null) }
            }
        }
    }

    fun exportZip(destination: Uri) {
        val images = _state.value.items.successful
        if (images.isEmpty() || _state.value.busyMessage != null) return
        _state.update { it.copy(busyMessage = "Saving ZIP…") }
        viewModelScope.launch {
            try {
                val count = withContext(Dispatchers.IO) {
                    ZipExporter.write(resolver, destination, images) { done, total ->
                        _state.update { it.copy(busyMessage = "Saving ZIP… $done / $total") }
                    }
                }
                postMessage("ZIP saved with $count file(s).")
            } catch (e: Exception) {
                withContext(Dispatchers.IO) {
                    try {
                        DocumentsContract.deleteDocument(resolver, destination)
                    } catch (ignored: Exception) {
                        // best effort cleanup of the partial file
                    }
                }
                postMessage("ZIP export failed: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                _state.update { it.copy(busyMessage = null) }
            }
        }
    }

    fun suggestedZipName(): String = ZipExporter.suggestedName()

    private fun postMessage(text: String) {
        _events.trySend(UiEvent.Message(text))
    }

    private companion object {
        const val MAX_KEY_INPUT = 64
    }
}
