package com.example.rpgrestorer.converter

/** A 16-byte RPG Maker encryption key. Its text form is never printed by toString(). */
class EncryptionKey private constructor(private val bytes: ByteArray) {

    /** XORs the first 16 bytes of [data] with the key, in place. */
    fun xorInPlace(data: ByteArray) {
        for (i in 0 until RpgFormat.KEY_LEN) {
            data[i] = (data[i].toInt() xor bytes[i].toInt()).toByte()
        }
    }

    fun toHex(): String = bytes.joinToString("") { "%02x".format(it.toInt() and 0xFF) }

    override fun equals(other: Any?): Boolean = other is EncryptionKey && other.bytes.contentEquals(bytes)
    override fun hashCode(): Int = bytes.contentHashCode()
    override fun toString(): String = "EncryptionKey(***)"

    companion object {
        fun fromBytes(source: ByteArray): EncryptionKey? =
            if (source.size == RpgFormat.KEY_LEN) EncryptionKey(source.copyOf()) else null

        /** Parses the 32-hex-character key found in System.json ("encryptionKey"). */
        fun parse(text: String): KeyParse {
            val t = text.trim()
            if (t.isEmpty()) return KeyParse.Empty
            if (t.length != RpgFormat.KEY_LEN * 2) {
                return KeyParse.Invalid("Key must be exactly 32 hex characters (it has ${t.length}).")
            }
            if (!t.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) {
                return KeyParse.Invalid("Key may only contain the characters 0-9 and a-f.")
            }
            val raw = ByteArray(RpgFormat.KEY_LEN) { i -> t.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
            return KeyParse.Valid(EncryptionKey(raw))
        }
    }
}

sealed interface KeyParse {
    data object Empty : KeyParse
    data class Invalid(val reason: String) : KeyParse
    data class Valid(val key: EncryptionKey) : KeyParse
}
