package com.example.rpgrestorer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.example.rpgrestorer.models.ExistingFilePolicy
import com.example.rpgrestorer.models.ThemeMode
import com.example.rpgrestorer.ui.UiState
import com.example.rpgrestorer.ui.components.ScreenHeader
import com.example.rpgrestorer.ui.components.SectionCard
import com.example.rpgrestorer.utils.folderLabel

@Composable
fun SettingsScreen(
    state: UiState,
    onBack: () -> Unit,
    onTheme: (ThemeMode) -> Unit,
    onPolicy: (ExistingFilePolicy) -> Unit,
    onChooseOutput: () -> Unit,
    onResetOutput: () -> Unit,
    onClearStorage: () -> Unit,
    onClearRecents: () -> Unit,
    modifier: Modifier = Modifier
) {
    var confirmOverwrite by remember { mutableStateOf(false) }

    if (confirmOverwrite) {
        AlertDialog(
            onDismissRequest = { confirmOverwrite = false },
            title = { Text("Replace existing files?") },
            text = {
                Text("Files in the output folder that have the same name will be permanently replaced. This cannot be undone.")
            },
            confirmButton = {
                TextButton(onClick = {
                    onPolicy(ExistingFilePolicy.OVERWRITE)
                    confirmOverwrite = false
                }) { Text("Allow replacing") }
            },
            dismissButton = { TextButton(onClick = { confirmOverwrite = false }) { Text("Cancel") } }
        )
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader("Settings", onBack = onBack) }
        item {
            SectionCard {
                Text("Appearance", style = MaterialTheme.typography.titleMedium)
                Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = state.theme == mode,
                            onClick = { onTheme(mode) },
                            label = { Text(mode.title) }
                        )
                    }
                }
            }
        }
        item {
            SectionCard {
                Text("If a file already exists", style = MaterialTheme.typography.titleMedium)
                ExistingFilePolicy.entries.forEach { policy ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = state.policy == policy,
                                role = Role.RadioButton,
                                onClick = {
                                    if (policy == ExistingFilePolicy.OVERWRITE) confirmOverwrite = true
                                    else onPolicy(policy)
                                }
                            )
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = state.policy == policy, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(policy.title, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                policy.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        item {
            SectionCard {
                Text("Output folder", style = MaterialTheme.typography.titleMedium)
                Text(
                    state.outputTree?.let { folderLabel(it) } ?: "App storage (not visible in file managers)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Row {
                    TextButton(onClick = onChooseOutput) { Text("Choose folder") }
                    if (state.outputTree != null) TextButton(onClick = onResetOutput) { Text("Use app storage") }
                }
            }
        }
        item {
            SectionCard {
                Text("Data", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = onClearStorage, enabled = !state.running) { Text("Clear results kept in app storage") }
                TextButton(onClick = onClearRecents) { Text("Clear recent conversions") }
            }
        }
        item {
            SectionCard {
                Text("About", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Version 1.1.0\n\n" +
                        "Works completely offline. This app declares no internet permission, " +
                        "has no analytics, and never uploads your files or keys. Encryption keys are kept in memory only.\n\n" +
                        "The key-free PNG restoration technique is the one documented by Petschko's " +
                        "RPG-Maker MV & MZ Decrypter (petschko.org/tools/mv_decrypter). " +
                        "This is an independent Kotlin implementation and is not affiliated with that project.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}
