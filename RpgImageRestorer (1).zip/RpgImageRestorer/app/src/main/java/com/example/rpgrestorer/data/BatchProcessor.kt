package com.example.rpgrestorer.data

import android.content.ContentResolver
import com.example.rpgrestorer.converter.RpgMakerCrypto
import com.example.rpgrestorer.models.ConversionItem
import com.example.rpgrestorer.models.ConversionMode
import com.example.rpgrestorer.models.ConversionPlan
import com.example.rpgrestorer.models.ConversionStatus
import com.example.rpgrestorer.models.ExistingFilePolicy
import com.example.rpgrestorer.models.ImageInfo
import com.example.rpgrestorer.models.OutputInfo
import com.example.rpgrestorer.utils.CountingOutputStream
import com.example.rpgrestorer.utils.FileNames
import com.example.rpgrestorer.utils.PngValidator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.IOException
import java.security.MessageDigest

/**
 * Converts a batch (decrypt or encrypt) with bounded parallelism. Every file is streamed (constant memory),
 * verified after writing, and reported through [onUpdate]. One failing file never stops the batch.
 * Originals are only ever read: outputs get a different extension and unique names.
 */
class BatchProcessor(
    private val resolver: ContentResolver,
    private val parallelism: Int = 3
) {
    suspend fun run(
        items: List<ConversionItem>,
        target: OutputTarget,
        policy: ExistingFilePolicy,
        plan: ConversionPlan,
        onUpdate: (ConversionItem) -> Unit
    ) = coroutineScope {
        val gate = Semaphore(parallelism)
        for (item in items) {
            launch(Dispatchers.IO) {
                gate.withPermit { process(item, target, policy, plan, onUpdate) }
            }
        }
    }

    private suspend fun process(
        item: ConversionItem,
        target: OutputTarget,
        policy: ExistingFilePolicy,
        plan: ConversionPlan,
        onUpdate: (ConversionItem) -> Unit
    ) {
        val name = item.input.name
        val decrypting = plan.mode == ConversionMode.DECRYPT
        if (!FileNames.isInputFor(plan.mode, name)) {
            val expected = if (decrypting) ".png_ or .rpgmvp" else ".png"
            onUpdate(item.copy(status = ConversionStatus.Failed("Unsupported file type (expected $expected)")))
            return
        }
        onUpdate(item.copy(status = ConversionStatus.Running))
        val ctx = currentCoroutineContext()
        var slot: OutputSlot? = null
        try {
            // Encrypting: prove the source is a real, decodable PNG before creating anything.
            var sourceInfo: ImageInfo? = null
            if (!decrypting) {
                sourceInfo = PngValidator.inspect(resolver, item.input.uri).getOrElse { e ->
                    onUpdate(item.copy(status = ConversionStatus.Failed("Not a valid PNG: ${e.message}")))
                    return
                }
            }

            val desired = if (decrypting) FileNames.restoredName(name) else FileNames.encryptedName(name, plan.format)
            val mime = if (decrypting) "image/png" else "application/octet-stream"
            slot = target.create(desired, policy, mime)
            val active: OutputSlot = slot ?: run {
                onUpdate(item.copy(status = ConversionStatus.Skipped("A file with this name already exists")))
                return
            }

            val input = resolver.openInputStream(item.input.uri)
                ?: throw IOException("Could not open the input file")
            val counter = CountingOutputStream(active.stream)
            val sourceDigest = if (decrypting) null else MessageDigest.getInstance("SHA-256")
            val error = input.use { i ->
                counter.use { o ->
                    if (decrypting) {
                        RpgMakerCrypto.decrypt(i, o, plan.key, null) { ctx.ensureActive() }
                    } else {
                        RpgMakerCrypto.encrypt(i, o, requireNotNull(plan.key), sourceDigest) { ctx.ensureActive() }
                    }
                }
            }
            if (error != null) {
                target.discard(active)
                onUpdate(item.copy(status = ConversionStatus.Failed(error)))
                return
            }

            // Verify the written file before reporting success.
            val info: ImageInfo
            if (decrypting) {
                info = PngValidator.inspect(resolver, active.uri).getOrElse { e ->
                    target.discard(active)
                    onUpdate(item.copy(status = ConversionStatus.Failed(e.message ?: "Verification failed")))
                    return
                }
            } else {
                val written = resolver.openInputStream(active.uri)
                val problem = if (written == null) {
                    "Verification failed: cannot reopen the output file"
                } else {
                    written.use {
                        RpgMakerCrypto.verifyEncrypted(
                            it, requireNotNull(plan.key), requireNotNull(sourceDigest).digest()
                        ) { ctx.ensureActive() }
                    }
                }
                if (problem != null) {
                    target.discard(active)
                    onUpdate(item.copy(status = ConversionStatus.Failed(problem)))
                    return
                }
                info = requireNotNull(sourceInfo)
            }
            onUpdate(
                item.copy(
                    status = ConversionStatus.Success,
                    output = OutputInfo(active.uri, active.name, info.width, info.height, counter.count)
                )
            )
        } catch (e: CancellationException) {
            withContext(NonCancellable) {
                slot?.let { target.discard(it) }
                onUpdate(item.copy(status = ConversionStatus.Cancelled))
            }
            throw e
        } catch (e: Exception) {
            slot?.let { target.discard(it) }
            onUpdate(item.copy(status = ConversionStatus.Failed(e.message ?: e.javaClass.simpleName)))
        }
    }
}
