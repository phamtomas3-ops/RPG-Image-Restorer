package com.example.rpgrestorer.ui.screens

import com.example.rpgrestorer.models.ConversionMode
import com.example.rpgrestorer.models.EncryptedFormat

/** All user actions of the home screen, grouped so the composable stays readable. */
class HomeActions(
    val onMode: (ConversionMode) -> Unit,
    val onSelectFiles: () -> Unit,
    val onSelectFolder: () -> Unit,
    val onClearSelection: () -> Unit,
    val onFormat: (EncryptedFormat) -> Unit,
    val onKeyChange: (String) -> Unit,
    val onKeyFromSystemJson: () -> Unit,
    val onKeyFromEncryptedImage: () -> Unit,
    val onChangeOutput: () -> Unit,
    val onResetOutput: () -> Unit,
    val onStart: () -> Unit,
    val onOpenSettings: () -> Unit,
    val onOpenResults: () -> Unit
)
