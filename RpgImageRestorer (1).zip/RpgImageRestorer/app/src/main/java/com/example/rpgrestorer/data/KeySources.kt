package com.example.rpgrestorer.data

import android.content.ContentResolver
import android.net.Uri
import com.example.rpgrestorer.converter.EncryptionKey
import com.example.rpgrestorer.converter.KeyParse
import com.example.rpgrestorer.converter.RpgFormat
import com.example.rpgrestorer.converter.RpgMakerCrypto
import org.json.JSONObject
import java.io.IOException

/** Reads an encryption key from files the user picks. Everything stays on the device. */
class KeySources(private val resolver: ContentResolver) {

    /** Reads the "encryptionKey" field of a game's System.json (plain text, normally < 1 MB). */
    fun fromSystemJson(uri: Uri): EncryptionKey {
        val stream = resolver.openInputStream(uri) ?: throw IOException("Cannot open the file")
        val bytes = stream.use { it.readLimited(MAX_JSON_BYTES) }
        val json = try {
            JSONObject(String(bytes, Charsets.UTF_8).trimStart('\uFEFF'))
        } catch (e: Exception) {
            throw IOException("This is not a readable System.json file")
        }
        val text = json.optString("encryptionKey", "")
        if (text.isBlank()) {
            throw IOException("System.json has no encryptionKey (the game may not use encrypted assets)")
        }
        return when (val parsed = EncryptionKey.parse(text)) {
            is KeyParse.Valid -> parsed.key
            is KeyParse.Invalid -> throw IOException("The key in System.json is malformed: ${parsed.reason}")
            KeyParse.Empty -> throw IOException("System.json has no encryptionKey")
        }
    }

    /** Derives the key from any encrypted .png_ / .rpgmvp of the game (reads only its first 32 bytes). */
    fun fromEncryptedImage(uri: Uri): EncryptionKey {
        val stream = resolver.openInputStream(uri) ?: throw IOException("Cannot open the file")
        val head = ByteArray(RpgFormat.HEADER_LEN + RpgFormat.KEY_LEN)
        val n = stream.use { s ->
            var total = 0
            while (total < head.size) {
                val r = s.read(head, total, head.size - total)
                if (r < 0) break
                total += r
            }
            total
        }
        if (n < head.size) throw IOException("File too small to be an encrypted image")
        return RpgMakerCrypto.deriveKey(head)
            ?: throw IOException("Not an RPG Maker encrypted file (no RPGMV header)")
    }

    private fun java.io.InputStream.readLimited(limit: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (true) {
            val r = read(buf)
            if (r < 0) break
            out.write(buf, 0, r)
            if (out.size() > limit) throw IOException("File is too large to be a System.json")
        }
        return out.toByteArray()
    }

    private companion object {
        const val MAX_JSON_BYTES = 8 * 1024 * 1024
    }
}
