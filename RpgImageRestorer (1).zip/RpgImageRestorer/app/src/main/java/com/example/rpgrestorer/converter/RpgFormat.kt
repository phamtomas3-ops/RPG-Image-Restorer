package com.example.rpgrestorer.converter

/**
 * Constants of the RPG Maker MV/MZ encrypted-asset container (shared by .rpgmvp and .png_).
 *
 * Layout: [16-byte header][file bytes, where the FIRST 16 bytes are XORed with the 16-byte key][rest unchanged]
 * Header = signature "RPGMV\0\0\0" (52 50 47 4D 56 00 00 00) + version 00 03 01 + remain 00 00 00 00 00.
 * The key is the 32-hex-character "encryptionKey" of System.json, read as 16 bytes.
 */
object RpgFormat {
    const val HEADER_LEN = 16
    const val KEY_LEN = 16
    const val MIN_PNG_SIZE = 45

    val HEADER: ByteArray = byteArrayOf(
        0x52, 0x50, 0x47, 0x4D, 0x56, 0x00, 0x00, 0x00,
        0x00, 0x03, 0x01,
        0x00, 0x00, 0x00, 0x00, 0x00
    )

    /** "RPGMV": the part of the header every reader checks. */
    val MAGIC: ByteArray = HEADER.copyOf(5)

    /** First 16 bytes of every PNG: signature + IHDR length (13) + "IHDR". */
    val PNG_HEADER: ByteArray = byteArrayOf(
        0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
        0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52
    )

    /** 'IEND' + CRC: the last 8 bytes of every well-formed PNG. */
    val PNG_IEND: ByteArray = byteArrayOf(
        0x49, 0x45, 0x4E, 0x44, 0xAE.toByte(), 0x42, 0x60, 0x82.toByte()
    )
}

internal fun ByteArray.startsWithBytes(prefix: ByteArray): Boolean =
    size >= prefix.size && prefix.indices.all { this[it] == prefix[it] }

internal fun ByteArray.endsWithBytes(suffix: ByteArray): Boolean =
    size >= suffix.size && suffix.indices.all { this[size - suffix.size + it] == suffix[it] }
