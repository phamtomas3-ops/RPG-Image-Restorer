package com.example.rpgrestorer.utils

import com.example.rpgrestorer.models.ConversionMode
import com.example.rpgrestorer.models.EncryptedFormat

object FileNames {
    private val SUPPORTED_EXTENSIONS = listOf(".png_", ".rpgmvp")
    private const val FORBIDDEN = "\\/:*?\"<>|"
    private const val MAX_BASE_LENGTH = 180

    fun isSupported(name: String): Boolean =
        SUPPORTED_EXTENSIONS.any { name.endsWith(it, ignoreCase = true) }

    /** "hero.png_" -> "hero.png". Unsafe characters are replaced so every file system accepts the name. */
    fun restoredName(original: String): String {
        var base = original.trim()
        SUPPORTED_EXTENSIONS.firstOrNull { base.endsWith(it, ignoreCase = true) }
            ?.let { base = base.dropLast(it.length) }
        return sanitize(base) + ".png"
    }

    fun isPng(name: String): Boolean = name.endsWith(".png", ignoreCase = true)

    /** Is [name] a valid input for the given operation? */
    fun isInputFor(mode: ConversionMode, name: String): Boolean =
        if (mode == ConversionMode.DECRYPT) isSupported(name) else isPng(name)

    /** "hero.png" -> "hero.png_" or "hero.rpgmvp". */
    fun encryptedName(original: String, format: EncryptedFormat): String {
        var base = original.trim()
        if (isPng(base)) base = base.dropLast(4)
        return sanitize(base) + format.extension
    }

    fun sanitize(text: String): String {
        val cleaned = buildString {
            for (c in text) append(if (c.isISOControl() || c in FORBIDDEN) '_' else c)
        }.trim().trimEnd('.')
        var limited = if (cleaned.length > MAX_BASE_LENGTH) cleaned.take(MAX_BASE_LENGTH) else cleaned
        if (limited.isNotEmpty() && limited.last().isHighSurrogate()) limited = limited.dropLast(1)
        return limited.trim().ifBlank { "image" }
    }

    /** "a.png", 1 -> "a (1).png" */
    fun withSuffix(name: String, number: Int): String {
        val dot = name.lastIndexOf('.')
        return if (dot > 0) "${name.substring(0, dot)} ($number)${name.substring(dot)}" else "$name ($number)"
    }
}
