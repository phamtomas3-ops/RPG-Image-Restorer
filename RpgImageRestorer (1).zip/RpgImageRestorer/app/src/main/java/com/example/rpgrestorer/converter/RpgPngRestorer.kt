package com.example.rpgrestorer.converter

import java.io.InputStream
import java.io.OutputStream

/**
 * Key-less restoration of RPG Maker MV/MZ encrypted PNGs (.png_ / .rpgmvp).
 *
 * Every PNG starts with the same 16 bytes, so the XOR-encrypted block can simply be replaced by that
 * constant: restored = PNG_HEADER + file[32..]. No key is needed. Kept for the in-memory API and
 * backwards compatibility; the streaming logic lives in [RpgMakerCrypto].
 */
object RpgPngRestorer {
    const val FAKE_HEADER_LEN = RpgFormat.HEADER_LEN
    const val PNG_HEAD_LEN = RpgFormat.KEY_LEN

    val PNG_HEADER: ByteArray = RpgFormat.PNG_HEADER

    sealed class Result {
        data class Ok(val png: ByteArray) : Result()
        data class Fail(val reason: String) : Result()
    }

    /** In-memory restoration (tests and small inputs). */
    fun restore(input: ByteArray): Result {
        if (input.isEmpty()) return Result.Fail("Empty file")
        if (input.size <= FAKE_HEADER_LEN + PNG_HEAD_LEN) {
            return Result.Fail("File too small to be an encrypted PNG")
        }
        if (!input.startsWithBytes(RpgFormat.MAGIC)) {
            return Result.Fail("Missing RPGMV header (not an encrypted RPG Maker file)")
        }
        val out = ByteArray(input.size - FAKE_HEADER_LEN)
        PNG_HEADER.copyInto(out, 0)
        input.copyInto(out, PNG_HEAD_LEN, FAKE_HEADER_LEN + PNG_HEAD_LEN, input.size)
        return validate(out)?.let { Result.Fail(it) } ?: Result.Ok(out)
    }

    /** Streaming key-less restoration. Returns null on success or a readable error. */
    fun restoreStream(
        input: InputStream,
        output: OutputStream,
        checkCancelled: () -> Unit = {}
    ): String? = RpgMakerCrypto.decrypt(input, output, null, null, checkCancelled)

    /** Structural check of a complete PNG; null when OK. */
    fun validate(png: ByteArray): String? {
        if (png.size < RpgFormat.MIN_PNG_SIZE) return "Too small for a PNG"
        if (!png.startsWithBytes(PNG_HEADER.copyOf(8))) return "Bad PNG signature"
        if (!png.endsWithBytes(RpgFormat.PNG_IEND)) return "Missing IEND chunk (file truncated or damaged)"
        return null
    }
}
