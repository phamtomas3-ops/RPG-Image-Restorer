package com.example.rpgrestorer.data

import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/** Writes into an app-private directory (used when no output folder has been chosen). */
class LocalDirTarget(private val dir: File) : BaseOutputTarget() {
    init {
        dir.mkdirs()
    }

    override fun listExisting(): List<String> = dir.list()?.toList() ?: emptyList()

    override fun createFile(name: String, mimeType: String): OutputSlot {
        val file = File(dir, name)
        return OutputSlot(Uri.fromFile(file), name, FileOutputStream(file).buffered(64 * 1024))
    }

    override fun deleteExisting(actualName: String) {
        File(dir, actualName).delete()
    }

    override suspend fun discard(slot: OutputSlot) {
        slot.uri.path?.let { File(it).delete() }
    }
}
