package com.example.rpgrestorer.converter

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.SequenceInputStream
import java.security.MessageDigest

/**
 * Tests against fixtures produced by tools/generate_test_vectors.py, an independent Python implementation
 * written from the published format description (see that file). The fixtures are NOT produced by this
 * app's code, so a mistake shared by encrypt and decrypt cannot hide here.
 */
class RpgMakerCryptoVectorTest {

    private fun res(name: String): ByteArray =
        javaClass.getResourceAsStream("/vectors/$name")!!.use { it.readBytes() }

    private fun ByteArray.hex() = joinToString("") { "%02x".format(it) }

    private val key = (EncryptionKey.parse(String(res("key.txt")).trim()) as KeyParse.Valid).key
    private val png = res("sample.png")
    private val encrypted = res("sample.png_")

    private fun decrypt(data: ByteArray, k: EncryptionKey?): Pair<String?, ByteArray> {
        val out = ByteArrayOutputStream()
        val error = RpgMakerCrypto.decrypt(ByteArrayInputStream(data), out, k)
        return error to out.toByteArray()
    }

    private fun encrypt(data: ByteArray, k: EncryptionKey = key): Pair<String?, ByteArray> {
        val out = ByteArrayOutputStream()
        val error = RpgMakerCrypto.encrypt(ByteArrayInputStream(data), out, k)
        return error to out.toByteArray()
    }

    // ---------- known answers ----------

    @Test fun fixtureSanity() {
        val sha = MessageDigest.getInstance("SHA-256").digest(png).hex()
        assertEquals(String(res("sample.sha256")).trim(), sha)
        assertEquals("01ef67508b387725f8c083480d9a552fba31ac2aaec4e97e6d73d6b382d71150", sha)
    }

    @Test fun knownAnswerFirst48Bytes() {
        // Computed by the Python generator: 16-byte RPGMV header + PNG header XOR key + start of IHDR.
        val expected = "5250474d5600000000030100000000002aa187395021528a6ce1f7a44a03960c000000100000001008060000001ff3ff"
        assertEquals(expected, encrypted.copyOf(48).hex())
        assertEquals(expected, encrypt(png).second.copyOf(48).hex())
    }

    @Test fun headerBytesAreExact() {
        assertEquals("5250474d560000000003010000000000", RpgFormat.HEADER.hex())
        assertEquals("89504e470d0a1a0a0000000d49484452", RpgFormat.PNG_HEADER.hex())
    }

    // ---------- decryption ----------

    @Test fun decryptsPngUnderscoreVector() {
        val (error, out) = decrypt(res("sample.png_"), key)
        assertNull(error)
        assertArrayEquals(png, out)
    }

    @Test fun decryptsRpgmvpVector() {
        val (error, out) = decrypt(res("sample.rpgmvp"), key)
        assertNull(error)
        assertArrayEquals(png, out)
    }

    @Test fun keylessDecryptionMatchesToo() {
        val (error, out) = decrypt(encrypted, null)
        assertNull(error)
        assertArrayEquals(png, out)
    }

    @Test fun bothExtensionsHaveIdenticalContent() {
        assertArrayEquals(res("sample.png_"), res("sample.rpgmvp"))
    }

    // ---------- encryption ----------

    @Test fun encryptionMatchesPythonVectorForPngUnderscore() {
        val (error, out) = encrypt(png)
        assertNull(error)
        assertArrayEquals(res("sample.png_"), out)
    }

    @Test fun encryptionMatchesPythonVectorForRpgmvp() {
        val (error, out) = encrypt(png)
        assertNull(error)
        assertArrayEquals(res("sample.rpgmvp"), out)
    }

    @Test fun encryptionDigestIsSourceSha256() {
        val md = MessageDigest.getInstance("SHA-256")
        RpgMakerCrypto.encrypt(ByteArrayInputStream(png), ByteArrayOutputStream(), key, md)
        assertEquals(String(res("sample.sha256")).trim(), md.digest().hex())
    }

    // ---------- round trips ----------

    @Test fun roundTripWithManyKeys() {
        val hexKeys = listOf(
            "00000000000000000000000000000000", "ffffffffffffffffffffffffffffffff",
            "0123456789abcdef0123456789ABCDEF", "a3f1c97e5d2b48806ce1f7a9034bd25e"
        )
        for (hex in hexKeys) {
            val k = (EncryptionKey.parse(hex) as KeyParse.Valid).key
            val (e1, enc) = encrypt(png, k)
            assertNull(e1)
            val (e2, dec) = decrypt(enc, k)
            assertNull(e2)
            assertArrayEquals(png, dec)
        }
    }

    @Test fun verifyEncryptedAcceptsGoodAndRejectsCorruptedOutput() {
        val sha = MessageDigest.getInstance("SHA-256").digest(png)
        assertNull(RpgMakerCrypto.verifyEncrypted(ByteArrayInputStream(encrypted), key, sha))
        val corrupted = encrypted.copyOf().also { it[100] = (it[100].toInt() xor 0x01).toByte() }
        val problem = RpgMakerCrypto.verifyEncrypted(ByteArrayInputStream(corrupted), key, sha)
        assertNotNull(problem)
        assertTrue(problem!!.contains("Verification failed"))
    }

    // ---------- wrong keys ----------

    @Test fun wrongKeyIsReportedNotSilentlyAccepted() {
        val wrong = (EncryptionKey.parse("a3f1c97e5d2b48806ce1f7a9034bd25f") as KeyParse.Valid).key // last nibble differs
        val (error, _) = decrypt(encrypted, wrong)
        assertNotNull(error)
        assertTrue(error!!.contains("Wrong key"))
    }

    @Test fun verifyWithWrongKeyFails() {
        val wrong = (EncryptionKey.parse("00000000000000000000000000000000") as KeyParse.Valid).key
        val sha = MessageDigest.getInstance("SHA-256").digest(png)
        assertNotNull(RpgMakerCrypto.verifyEncrypted(ByteArrayInputStream(encrypted), wrong, sha))
    }

    // ---------- key derivation ----------

    @Test fun derivesTheKeyFromAnEncryptedImage() {
        assertEquals(key, RpgMakerCrypto.deriveKey(encrypted.copyOf(32)))
        assertEquals(key.toHex(), RpgMakerCrypto.deriveKey(encrypted)!!.toHex())
    }

    @Test fun keyDerivationRejectsNonEncryptedData() {
        assertNull(RpgMakerCrypto.deriveKey(png))
        assertNull(RpgMakerCrypto.deriveKey(ByteArray(10)))
    }

    // ---------- invalid, empty, truncated ----------

    @Test fun emptyFiles() {
        assertEquals("Empty file", decrypt(ByteArray(0), key).first)
        assertEquals("Empty file", decrypt(ByteArray(0), null).first)
        assertEquals("Empty file", encrypt(ByteArray(0)).first)
    }

    @Test fun decryptRejectsNonRpgMakerData() {
        assertTrue(decrypt(ByteArray(100) { it.toByte() }, key).first!!.contains("RPGMV"))
        assertTrue(decrypt(png, key).first!!.contains("RPGMV")) // a plain PNG is not an encrypted file
        assertTrue(decrypt(ByteArray(20), key).first!!.contains("small"))
    }

    @Test fun decryptRejectsTruncatedAndHeaderOnlyFiles() {
        assertTrue(decrypt(encrypted.copyOf(encrypted.size - 3), key).first!!.contains("IEND"))
        assertTrue(decrypt(encrypted.copyOf(32), key).first!!.contains("Too small"))
    }

    @Test fun encryptRejectsNonPngInput() {
        assertTrue(encrypt(encrypted).first!!.contains("Not a PNG"))
        assertTrue(encrypt(ByteArray(10)).first!!.contains("small"))
        val badIhdr = png.copyOf().also { it[12] = 'X'.code.toByte() }
        assertTrue(encrypt(badIhdr).first!!.contains("Unsupported PNG layout"))
    }

    @Test fun encryptRejectsTruncatedPng() {
        assertTrue(encrypt(png.copyOf(png.size - 4)).first!!.contains("IEND"))
    }

    @Test fun cancellationPropagates() {
        class Stop : RuntimeException()
        try {
            RpgMakerCrypto.encrypt(ByteArrayInputStream(png), ByteArrayOutputStream(), key) { throw Stop() }
            throw AssertionError("expected cancellation")
        } catch (e: Stop) {
        }
    }

    // ---------- large files (streamed, constant memory) ----------

    @Test fun largeFileRoundTripIsStreamedAndVerified() {
        val bodySize = 64L * 1024 * 1024
        val iend = byteArrayOf(0, 0, 0, 0, 0x49, 0x45, 0x4E, 0x44, 0xAE.toByte(), 0x42, 0x60, 0x82.toByte())
        fun source(): InputStream = SequenceInputStream(
            SequenceInputStream(ByteArrayInputStream(RpgFormat.PNG_HEADER), PatternStream(bodySize)),
            ByteArrayInputStream(iend)
        )
        val temp = File.createTempFile("rpgmv-large", ".png_")
        try {
            val md = MessageDigest.getInstance("SHA-256")
            val error = FileOutputStream(temp).buffered().use { out ->
                RpgMakerCrypto.encrypt(source(), out, key, md)
            }
            assertNull(error)
            assertEquals(16L + 16L + bodySize + 12L, temp.length())
            val expectedSha = md.digest()
            assertNull(FileInputStream(temp).use { RpgMakerCrypto.verifyEncrypted(it, key, expectedSha) })

            // independently recompute the source hash and compare with the decrypted stream's hash
            val sourceMd = MessageDigest.getInstance("SHA-256")
            source().use { s ->
                val buf = ByteArray(65536)
                while (true) { val r = s.read(buf); if (r < 0) break; sourceMd.update(buf, 0, r) }
            }
            assertArrayEquals(sourceMd.digest(), expectedSha)
        } finally {
            temp.delete()
        }
    }

    /** Deterministic pseudo-random bytes without holding them in memory. */
    private class PatternStream(private var remaining: Long) : InputStream() {
        private var seed = 12345
        private fun next(): Int {
            seed = seed * 1103515245 + 12345
            return (seed ushr 16) and 0xFF
        }
        override fun read(): Int {
            if (remaining <= 0) return -1
            remaining--
            return next()
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = minOf(len.toLong(), remaining).toInt()
            for (i in 0 until n) b[off + i] = next().toByte()
            remaining -= n
            return n
        }
    }
}
