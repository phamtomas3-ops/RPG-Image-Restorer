package com.example.rpgrestorer.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import com.example.rpgrestorer.models.ConversionMode
import com.example.rpgrestorer.models.EncryptedFormat
import org.junit.Test

class FileNamesTest {
    @Test fun changesExtension() {
        assertEquals("hero.png", FileNames.restoredName("hero.png_"))
        assertEquals("HERO.png", FileNames.restoredName("HERO.PNG_"))
        assertEquals("a.png", FileNames.restoredName("a.rpgmvp"))
        assertEquals("name.with.dots.png", FileNames.restoredName("name.with.dots.png_"))
    }

    @Test fun replacesUnsafeCharacters() {
        assertEquals("we_ird_na_me.png", FileNames.restoredName("we:ird*na?me.png_"))
        assertEquals("a_b.png", FileNames.restoredName("a/b.png_"))
    }

    @Test fun handlesDegenerateNames() {
        assertEquals("image.png", FileNames.restoredName(".png_"))
        assertEquals("image.png", FileNames.restoredName("...png_"))
        assertEquals("image.png", FileNames.restoredName("   .png_"))
    }

    @Test fun keepsUnicode() {
        assertEquals("勇者 (戦闘).png", FileNames.restoredName("勇者 (戦闘).png_"))
    }

    @Test fun limitsLength() {
        assertTrue(FileNames.restoredName("x".repeat(500) + ".png_").length <= 184)
    }

    @Test fun addsNumericSuffix() {
        assertEquals("a (1).png", FileNames.withSuffix("a.png", 1))
        assertEquals("a (12).png", FileNames.withSuffix("a.png", 12))
        assertEquals("noext (2)", FileNames.withSuffix("noext", 2))
    }

    @Test fun recognisesSupportedExtensions() {
        assertTrue(FileNames.isSupported("x.png_"))
        assertTrue(FileNames.isSupported("x.RPGMVP"))
        assertFalse(FileNames.isSupported("x.rpgmvm"))
        assertFalse(FileNames.isSupported("x.png"))
    }

    @Test fun encryptedNamesUseTheChosenExtension() {
        assertEquals("hero.png_", FileNames.encryptedName("hero.png", EncryptedFormat.PNG_UNDERSCORE))
        assertEquals("HERO.rpgmvp", FileNames.encryptedName("HERO.PNG", EncryptedFormat.RPGMVP))
        assertEquals("a_b.rpgmvp", FileNames.encryptedName("a:b.png", EncryptedFormat.RPGMVP))
        assertEquals("image.png_", FileNames.encryptedName(".png", EncryptedFormat.PNG_UNDERSCORE))
        assertEquals("勇者.rpgmvp", FileNames.encryptedName("勇者.png", EncryptedFormat.RPGMVP))
    }

    @Test fun inputsAreCheckedPerOperation() {
        assertTrue(FileNames.isInputFor(ConversionMode.ENCRYPT, "a.png"))
        assertFalse(FileNames.isInputFor(ConversionMode.ENCRYPT, "a.png_"))
        assertTrue(FileNames.isInputFor(ConversionMode.DECRYPT, "a.png_"))
        assertTrue(FileNames.isInputFor(ConversionMode.DECRYPT, "a.rpgmvp"))
        assertFalse(FileNames.isInputFor(ConversionMode.DECRYPT, "a.png"))
    }
}
