package com.example.rpgrestorer.data

import com.example.rpgrestorer.models.ExistingFilePolicy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NameAllocatorTest {
    private fun allocator(vararg existing: String) = NameAllocator { existing.toList() }

    @Test fun duplicatesInsideOneBatchGetNumbers() = runBlocking {
        val a = allocator()
        assertEquals("a.png", a.allocate("a.png", ExistingFilePolicy.RENAME)!!.name)
        assertEquals("a (1).png", a.allocate("a.png", ExistingFilePolicy.RENAME)!!.name)
        assertEquals("a (2).png", a.allocate("A.PNG", ExistingFilePolicy.RENAME)!!.name) // case-insensitive
    }

    @Test fun duplicatesInsideOneBatchAreRenamedEvenWhenPolicyIsSkipOrOverwrite() = runBlocking {
        for (policy in listOf(ExistingFilePolicy.SKIP, ExistingFilePolicy.OVERWRITE)) {
            val a = allocator()
            a.allocate("x.png_", policy)
            assertEquals("x (1).png_", a.allocate("x.png_", policy)!!.name)
        }
    }

    @Test fun existingFilesFollowThePolicy() = runBlocking {
        assertEquals("pic (1).png", allocator("pic.png").allocate("pic.png", ExistingFilePolicy.RENAME)!!.name)
        assertNull(allocator("pic.png").allocate("pic.png", ExistingFilePolicy.SKIP))
        val replace = allocator("Pic.PNG").allocate("pic.png", ExistingFilePolicy.OVERWRITE)!!
        assertEquals("pic.png", replace.name)
        assertEquals("Pic.PNG", replace.replaceExisting)
    }

    @Test fun suffixSkipsNamesThatAlreadyExist() = runBlocking {
        val a = allocator("a.png", "a (1).png", "a (2).png")
        assertEquals("a (3).png", a.allocate("a.png", ExistingFilePolicy.RENAME)!!.name)
    }

    @Test fun renameNeverReplacesAnything() = runBlocking {
        val r = allocator("a.png").allocate("a.png", ExistingFilePolicy.RENAME)!!
        assertNull(r.replaceExisting)
    }

    @Test fun manyParallelConversionsWithTheSameNameNeverCollide() = runBlocking {
        val a = allocator("name.png_")
        val names = (1..300).map {
            async(Dispatchers.Default) { a.allocate("name.png_", ExistingFilePolicy.RENAME)!!.name }
        }.awaitAll()
        assertEquals(300, names.map { it.lowercase() }.toSet().size)
        assertTrue("name.png_" !in names) // the pre-existing file is protected
        assertNotNull(names.firstOrNull { it == "name (1).png_" })
    }

    @Test fun listingIsReadOnlyOnce() = runBlocking {
        var calls = 0
        val a = NameAllocator { calls++; emptyList() }
        repeat(5) { a.allocate("f$it.png", ExistingFilePolicy.RENAME) }
        assertEquals(1, calls)
    }
}
