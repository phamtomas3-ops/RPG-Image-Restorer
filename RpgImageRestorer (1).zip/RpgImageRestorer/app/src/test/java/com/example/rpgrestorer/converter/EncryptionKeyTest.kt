package com.example.rpgrestorer.converter

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EncryptionKeyTest {
    @Test fun emptyAndBlankAreEmpty() {
        assertEquals(KeyParse.Empty, EncryptionKey.parse(""))
        assertEquals(KeyParse.Empty, EncryptionKey.parse("   \n"))
    }

    @Test fun validKeyAcceptsBothCasesAndTrimsWhitespace() {
        val lower = EncryptionKey.parse("a3f1c97e5d2b48806ce1f7a9034bd25e")
        val upper = EncryptionKey.parse("  A3F1C97E5D2B48806CE1F7A9034BD25E \n")
        assertTrue(lower is KeyParse.Valid)
        assertEquals((lower as KeyParse.Valid).key, (upper as KeyParse.Valid).key)
        assertEquals("a3f1c97e5d2b48806ce1f7a9034bd25e", lower.key.toHex())
    }

    @Test fun rejectsWrongLength() {
        assertTrue(EncryptionKey.parse("abcd") is KeyParse.Invalid)
        assertTrue(EncryptionKey.parse("a".repeat(33)) is KeyParse.Invalid)
        assertTrue(EncryptionKey.parse("a".repeat(31)) is KeyParse.Invalid)
    }

    @Test fun rejectsNonHexCharacters() {
        val bad = "g3f1c97e5d2b48806ce1f7a9034bd25e"
        val r = EncryptionKey.parse(bad)
        assertTrue(r is KeyParse.Invalid)
        assertTrue((r as KeyParse.Invalid).reason.contains("0-9"))
        assertTrue(EncryptionKey.parse("a3f1c97e 5d2b4880 6ce1f7a9 034bd25e") is KeyParse.Invalid)
    }

    @Test fun toStringNeverRevealsTheKey() {
        val k = (EncryptionKey.parse("a3f1c97e5d2b48806ce1f7a9034bd25e") as KeyParse.Valid).key
        assertFalse(k.toString().contains("a3f1"))
        assertFalse(KeyParse.Valid(k).toString().contains("a3f1"))
    }

    @Test fun fromBytesChecksLength() {
        assertNull(EncryptionKey.fromBytes(ByteArray(15)))
        assertNotNull(EncryptionKey.fromBytes(ByteArray(16)))
    }
}
